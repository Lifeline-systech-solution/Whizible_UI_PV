﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="RM_GlobalResourcePool.aspx.vb" Inherits="PbNIT.RM_GlobalResourcePool" %>

<!DOCTYPE html>
<html>

<head runat="server">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Resource</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/jquery-ui.css?v=2">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap.min.css?v=1">
    <!-- bootstrap select -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap-select.css?v=2">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../Whizible2.0/fontawesome/css/all.css?v=2">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/AdminLTE.min.css?v=2">
    <!-- animate css -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/animate.css?v=2">
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/dataTables.bootstrap.min.css?v=0">
    <!-- custom style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom.css?v=3">
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom_project.css?v=3.1">
    <!-- media_queries -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/media_queries.css?v=2">
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/adavanced_filter.css?v=0.1">
    <!-- custom style -->
    <%-- <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom_issues.css?v=2.10" />--%>
    <!-- media_queries -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/media_queries.css?v=1" />
    <link href="../../../Plugins/alertify/css/alertify.min.css" rel="stylesheet" />
    <style type="text/css">
        .dataTables_scrollBody thead tr[role="row"] {
            visibility: collapse !important;
        }

        a.clearalllink {
            font-weight: bold;
            margin: 7px 0px 0 8px;
            display: none;
        }

        .filter.pull-right {
            margin: 2px 0 0 8px;
        }

        table tr th {
            vertical-align: middle !important;
        }

            table tr td:last-child .custom_chckbox label:before, table tr th:last-child .custom_chckbox label:before {
                margin-right: 0;
            }

        .notebox {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
        }

        .dropdown-submenu .dropdown-submenu > a:after {
            border-color: transparent transparent transparent #fff;
            border-style: solid;
            border-width: 5px 0 5px 5px;
            content: " ";
            display: block;
            float: right;
            height: 0;
            margin-right: 10px;
            margin-top: 5px;
            width: 0;
        }

        .dropdown-submenu > .dropdown-submenu:hover a:after {
            border-color: transparent transparent transparent #464a4c;
        }


        /*Detailpanel*/
        .Resourcedetailpanel {
            margin: 40px 15px 0;
            display: none;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

            .Resourcedetailpanel:hover {
                cursor: auto;
            }

        .pgdetailinner {
            padding: 10px;
        }

        .Resourcedetailpanel .tab-pane {
            padding: 20px 0;
        }

        tr.rowhiglight {
            background: #c3dbff;
        }

        .DisableContent {
            pointer-events: none;
            opacity: 0.5;
        }
        /*.DisableContent:not(.Resourcedetailpanel):hover{ cursor:not-allowed;}*/
        /*.GRPtblwraps .dataTables_scrollBody.DisableContent{ height:auto!important}*/
        ul.nav.nav-tabs.detailsubtabs {
            background: #f5f5f5;
            margin: -11px -11px;
            padding: 10px 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px 4px 0 0;
        }

        .nav.detailsubtabs > li > a:hover, .nav.nav.detailsubtabs > li > a:active, .nav.nav.detailsubtabs > li > a:focus {
            background: #fff;
            color: #1359ac;
        }

        h5.pgtitle {
            margin: 6px 0 0;
            font-weight: 700;
            color: #4263c1;
            font-size: 16px;
        }

        .dblock {
            display: block;
        }

        .dataTable > thead > tr > th[class*="sort"]:after {
            content: "" !important;
        }

        table.dataTable thead > tr > th.sorting_asc,
        table.dataTable thead > tr > th.sorting_desc,
        table.dataTable thead > tr > th.sorting,
        table.dataTable thead > tr > td.sorting_asc,
        table.dataTable thead > tr > td.sorting_desc,
        table.dataTable thead > tr > td.sorting {
            padding-right: inherit;
        }

        body#bodyGlobal-Resource {
            padding-right: 0 !important;
        }

        /*.alertify-notifier li {
            word-break: normal !important;
            white-space: normal !important;
            background-color: red !important;
        }

        .alertifySuccess li {
            word-break: normal !important;
            white-space: normal !important;
            background-color: darkseagreen !important;
        }

        .alertify-notifier .ajs-message {
            width: 500px !important;
            height: 60px;
            word-break: break-word;
            background-color: red !important;
        }*/

        .alertify-notifier {
            position: fixed;
            width: 0;
            overflow: visible;
            z-index: 99999 !important;
            -webkit-transform: translate3d(0,0,0);
            transform: translate3d(0,0,0);
            /*word-break: break-all;*/
        }


        #GRPtblmain_wrapper .dataTables_paginate {
            margin-top: 20px;
        }

        #GRPtblmain_wrapper table {
            width: 100% !important;
        }

        #GRPtbl_wrapper .dataTables_paginate {
            margin-top: 20px;
        }

        #GRPtbl_wrapper table {
            width: 100% !important;
        }

        .clsShowHide {
            display: none !important;
        }

        .filterpanel .issfilter_actiondropdown {
            float: right;
        }

        .issfilter_actiondropdown {
            float: right;
        }

        .filterpanel .MyFiltersdropdown li span i {
            font-size: 14px;
            cursor: pointer;
            padding: 9px;
        }

        .unsavedHeading {
            color: red;
            font-style: italic;
            font-weight: 900;
        }

        .unsavedText {
            color: red;
            font-style: italic;
        }

        .editFilter {
            color: #1359a6;
            border: 1px;
            border-style: dotted;
            background: aliceblue;
        }

        .issuefilter_container .filterpanelbody {
            background: #ffffff;
        }

        .preloader {
            position: absolute;
            margin-top: -25px;
            margin-left: -400px;
            top: 50%;
            left: 50%;
            padding: 30px 15px 0px;
            /* border: 3px solid #ababab; */
            /* box-shadow: 1px 1px 10px #ababab; */
            border-radius: 15px;
            background: #ddd;
            /* background-color: white; */
            background: url(../../../Whizible2.0/dist/img/loading.gif) 100% 100% no-repeat;
            /* background: url(../../../Whizible2.0/dist/img/loading.gif) rgba( 255, 255, 255, .8 ) 100% 100% no-repeat; */
            width: 100px;
            height: 100px;
            background-repeat: no-repeat;
            background-position: center;
            margin: -100px 0 0 -100px;
            z-index: 1002;
            text-align: center;
        }

        .clTextCenter {
            text-align: center;
        }

        .clTextLeft {
            text-align: left;
        }

        .clTextRight {
            text-align: right;
        }

        .clsFilterHighlight {
            background: #1359a6 !important;
            color: #ffffff !important;
        }

        .btnrow {
            margin-top: 20px;
        }

        .filter button[aria-expanded="true"] {
            background: NONE;
            color: #4263c1;
            padding: 4px 6px;
            font-size: 12px;
            border-radius: 4px;
        }
    </style>

</head>

<body class="hold-transition skin-blue-light sidebar-mini fixed" id="bodyGlobal-Resource">

    <div class="bgwhite">

        <div class="container-fluid pt-1 pb-1 mb-1 text-right graybg">
            <h5 class="pgtitle pull-left">Global Resource Pool</h5>
            <%--Commented By Rutuja D. on 1 July 2021 For Hide Back Button--%>
            <%--<a href="RM_ResourcePlanIndex.aspx" class="btn borderbtn backbtn" id="" data-toggle="tooltip" data-placement="bottom" title="Back to Resource Configuration">Back</a>--%>
            <%--End of Commented By Rutuja D. on 1 July 2021 For Hide Back Button--%>
            <a href="javascript:;" class="mainclearalllink" data-toggle="tooltip" data-placement="bottom" title=""><strong>Clear All</strong></a>

            <div class="filter inline pull-right">
                <button data-toggle="collapse" data-target="#filterpanel" data-placement="bottom" title="" id="AdvanceFilterIcon" data-original-title="Filter" autocomplete="off"><i class="fas fa-filter"></i></button>
            </div>
        </div>
        <!--filter panel-->
        <div id="filterpanel" class="filterpanel collapse">
            <div class="bglightgray container-fluid pt-1 pb-1 headertopp filterpanelheader">

                <div class="cust_tabpanel">
                    <ul class="nav nav-tabs">
                        <li class="dropdown">
                            <a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">My Filters  <span class="caret"></span></a>
                            <ul id="MyFiltersdropdown" class="dropdown-menu MyFiltersdropdown" role="menu">

                                <%--<li>
                                    <label class="customradio">
                                        <input class="myfilter_selectprocheckbox" data-toggle="tooltip" data-placement="bottom" id="project2" type="checkbox" name="project2" onchange="" data-original-title="" title="">
                                        <span data-toggle="tooltip" data-placement="right" title="" class="checkmark" data-original-title="Set Default filter"></span>
                                    </label>
                                    <label class="">
                                        <span for="project2" class="radiotextsty filtername">Project 2 and 3</span>
                                    </label>

                                    <div class="issfilter_actiondropdown">
                                        <div class="custom_chckbox_markblue">
                                            <input id="IssueselproOne" type="checkbox" name="">
                                            <label data-toggle="tooltip" data-container="body" data-placement="bottom" title="" for="IssueselproOne" data-original-title="Apply filter"></label>
                                        </div>
                                        <span class="edit_filter">
                                            <img src="../../../Whizible2.0/dist/img/edit.svg" width="16px" data-toggle="tooltip" data-container="body" data-placement="bottom" title="" data-original-title="Edit filter"></span>
                                        <span><i data-toggle="tooltip" data-container="body" data-placement="bottom" title="" class="far fa-trash-alt" data-original-title="Delete filter"></i></span>
                                    </div>
                                </li>
                                <li>
                                    <label class="customradio">
                                        <input class="myfilter_selectprocheckbox" data-toggle="tooltip" data-placement="bottom" id="task" type="checkbox" name="task" onchange="" data-original-title="" title="">
                                        <span data-toggle="tooltip" data-placement="right" title="" class="checkmark" data-original-title="Set Default filter"></span>
                                    </label>
                                    <label class="">
                                        <span for="task" class="radiotextsty">Task and milestones</span>
                                    </label>

                                    <div class="issfilter_actiondropdown">
                                        <div class="custom_chckbox_markblue">
                                            <input id="IssueselproTwo" type="checkbox" name="">
                                            <label data-toggle="tooltip" data-container="body" data-placement="bottom" title="" for="IssueselproTwo" data-original-title="Apply filter"></label>
                                        </div>
                                        <span class="edit_filter">
                                            <img src="../../../Whizible2.0/dist/img/edit.svg" width="16px" data-toggle="tooltip" data-container="body" data-placement="bottom" title="" data-original-title="Edit filter"></span>
                                        <span><i data-toggle="tooltip" data-container="body" data-placement="bottom" title="" class="far fa-trash-alt" data-original-title="Delete filter"></i></span>
                                    </div>
                                </li>
                                <li>
                                    <label class="customradio">
                                        <input class="myfilter_selectprocheckbox" data-toggle="tooltip" data-placement="bottom" id="groupcompany" type="checkbox" name="groupcompany" onchange="" data-original-title="" title="">
                                        <span data-toggle="tooltip" data-placement="right" title="" class="checkmark" data-original-title="Set Default filter"></span>
                                    </label>
                                    <label class="">
                                        <span for="groupcompany" class="radiotextsty">For group company</span>
                                    </label>

                                    <div class="issfilter_actiondropdown">
                                        <div class="custom_chckbox_markblue">
                                            <input id="IssueselproThree" type="checkbox" name="">
                                            <label data-container="body" data-toggle="tooltip" data-placement="bottom" title="" for="IssueselproThree" data-original-title="Apply filter"></label>
                                        </div>
                                        <span class="edit_filter">
                                            <img src="../../../Whizible2.0/dist/img/edit.svg" width="16px" data-toggle="tooltip" data-container="body" data-placement="bottom" title="" data-original-title="Edit filter"></span>
                                        <span><i data-toggle="tooltip" data-container="body" data-placement="bottom" title="" class="far fa-trash-alt" data-original-title="Delete filter"></i></span>
                                    </div>
                                </li>--%>
                            </ul>
                        </li>
                        <li class="" id="tabpresetfilter">
                            <a href="#basicfilters" data-toggle="tab" aria-expanded="true">Basic Filters</a>
                        </li>


                    </ul>
                </div>

                <div class="Fwrapper">
                    <div class="tab-content">
                        <div id="basicfilters" class="tab-pane stackbasicfilter">
                            <div class="filterpanelbody">
                                <div class="text-center hidden-xs centerbtn">
                                    <button class="btn btnyellow" id="svfilterbtn" data-toggle="modal" onclick="checkFiltervalidationForGRP();">Save and Apply</button>
                                    <button class="btn btnyellow" onclick="ApplyFlter()">Apply</button>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>Global Resource Pool Code</label>
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <select class="form-control input-sm" id="cboGRPFilterGlobalResourcePoolCode">
                                                    <option value="Contains">Contains</option>
                                                    <option value="Ends With">End With</option>
                                                    <option value="Exact Word">Exact Word</option>
                                                    <option value="Not Contains">Not Contains</option>
                                                    <option value="Starts With">Start With</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6 pl-0">
                                                <% CommonFunctions.HTMLControls.DrawTextBox("txtGRPFilterGlobalResourcePoolCode", "txtGRPFilterGlobalResourcePoolCode", "form-control",,,,,, ,,,, "  ",, ,,,,, True) %>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label>Global Resource Pool Name</label>
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <select class="form-control input-sm" id="cboGRPFilterGlobalResourcePoolName">
                                                    <option value="Contains">Contains</option>
                                                    <option value="Ends With">End With</option>
                                                    <option value="Exact Word">Exact Word</option>
                                                    <option value="Not Contains">Not Contains</option>
                                                    <option value="Starts With">Start With</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6 pl-0">
                                                <% CommonFunctions.HTMLControls.DrawTextBox("txtGRPFilterGlobalResourcePoolName", "txtGRPFilterGlobalResourcePoolName", "form-control",,,,,, ,,,, "  ",, ,,,,, True) %>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <!--end filter panel-->

        <div class="content pt-1">
            <div class="GRPtblwraps">
                <table class="table table-bordered GRPtbl" style="width: 100%;" id="GRPtbl">
                    <thead>
                        <tr>
                            <th class="text-left">Global Resource Pool Code</th>
                            <th class="text-left">Global Resource Pool Name</th>
                        </tr>
                    </thead>
                    <tbody id="tblGlobalResourcePool">
                    </tbody>
                </table>
            </div>
        </div>


        <div class="Resourcedetailpanel">
            <input type="hidden" id="hdnGRP_UniqueIDTab" name="hdnGRP_UniqueIDTab">
            <input type="hidden" id="hdnGRP_GlobalResourcePoolTab" name="hdnGRP_GlobalResourcePoolTab">
            <input type="hidden" id="hdnGRP_GlobalResourcePoolIsActive" name="hdnGRP_GlobalResourcePoolIsActive">
            <input type="hidden" id="hdnGRP_MangerIDTab" name="hdnGRP_MangerIDTab" value="0">


            <div class="pgdetailinner">
                <ul class="nav nav-tabs detailsubtabs">
                    <li class="active"><a href="#GRPdetails" data-toggle="tab" id="">Details</a><div></div>
                    </li>
                    <li class="" onclick="ShowGRPManager();"><a href="#GRPMangrs" data-toggle="tab" id="GrpPollManagerTab">Global Resource Pool Manager</a><div></div>
                    </li>
                    <li class="" onclick="ShowGraph();"><a href="#GRPgrph" data-toggle="tab" id="">By Role</a><div></div>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="GRPdetails" class="tab-pane active">
                        <div class="detailsubtabsbtn pb-1 text-right">
                            <button class="btn borderbtn canceldetailpanel mr-5" id="" onclick="cancledetailpanel()">Cancel</button>
                        </div>

                        <div class="row">
                            <div class="col-sm-4">
                                <label class="required">Global Resource Pool Code</label>
                                <%--    <input type="text" class="form-control" value="GRP" disabled />--%>
                                <% CommonFunctions.HTMLControls.DrawTextBox("CboResource", "usp_SEL_ProjectValue", value:="GRP", IsDisabled:=True, cssClass:="form-control") %>
                            </div>

                            <div class="col-sm-4">
                                <label>Global Resource Pool Name</label>
                                <%-- <input type="text" class="form-control" value="Global Resource Pool" disabled />--%>
                                <% CommonFunctions.HTMLControls.DrawTextBox("CboResource", "usp_SEL_ProjectValue", value:="Global Resource Pool", IsDisabled:=True, cssClass:="form-control") %>
                            </div>
                        </div>

                    </div>

                    <div id="GRPMangrs" class="tab-pane">
                        <div class="detailsubtabsbtn pt-1 pb-1 text-right">
                            <button type="submit" class="btn borderbtn mr-5" id="AddGRP" data-toggle="modal" data-target="#AddGRPMModal" onclick="GRPEnableManagerlist()"><i class="fa fa-plus" aria-hidden="true"></i>Add</button>
                            <button class="btn borderbtn mr-5" id="DeleteGRP" onclick="DeleteGRPManager();">Delete</button>
                            <button class="btn borderbtn canceldetailpanel mr-5" id="" onclick="cancledetailpanel()">Cancel</button>
                        </div>

                        <table class="table table-bordered GRPdetailTbl" style="width: 100%;" id="GRPtblmain">
                            <thead>
                                <tr>
                                    <th>Manager</th>
                                    <th>Is Primary Responsible</th>
                                    <th>
                                        <div class="custom_chckbox">
                                            <input id="GRPmngrcheck0" class="chckHead" type="checkbox">
                                            <label for="GRPmngrcheck0"></label>
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="tblGlobalResourcePoolManager">
                                <%--<tr>
                                        <td><a href="javascript:;" data-toggle="modal" data-target="#AddGBPMModal">Amit Patil</a></td>
                                        <td>Yes</td>
                                        <td>
                                            <div class="custom_chckbox">
                                                <input id="GRPmngrcheck1" class="chcktbl" type="checkbox">
                                                <label for="GRPmngrcheck1"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="javascript:;" data-toggle="modal" data-target="#AddGBPMModal">Pradip Pradhan</a></td>
                                        <td>Yes</td>
                                        <td>
                                            <div class="custom_chckbox">
                                                <input id="GRPmngrcheck2" class="chcktbl" type="checkbox">
                                                <label for="GRPmngrcheck2"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="javascript:;" data-toggle="modal" data-target="#AddGBPMModal">Lorem Ipsum</a></td>
                                        <td>Yes</td>
                                        <td>
                                            <div class="custom_chckbox">
                                                <input id="GRPmngrcheck3" class="chcktbl" type="checkbox">
                                                <label for="GRPmngrcheck3"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="javascript:;" data-toggle="modal" data-target="#AddGBPMModal">Amit Patil</a></td>
                                        <td>Yes</td>
                                        <td>
                                            <div class="custom_chckbox">
                                                <input id="GRPmngrcheck4" class="chcktbl" type="checkbox">
                                                <label for="GRPmngrcheck4"></label>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><a href="javascript:;" data-toggle="modal" data-target="#AddGBPMModal">John K</a></td>
                                        <td>Yes</td>
                                        <td>
                                            <div class="custom_chckbox">
                                                <input id="GRPmngrcheck5" class="chcktbl" type="checkbox">
                                                <label for="GRPmngrcheck5"></label>
                                            </div>
                                        </td>
                                    </tr>--%>
                            </tbody>
                        </table>
                    </div>
                    <div id="GRPgrph" class="tab-pane">
                        <p class="pull-left">Resources by Role</p>
                        <div class="detailsubtabsbtn pt-1 pb-1 text-right">
                            <button class="btn borderbtn canceldetailpanel mr-5" id="">Cancel</button>
                        </div>
                        <div class="graphcontainer">
                            <canvas id="RRChart" width="80" height="20"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="clearfix"></div>
    </div>


    <!--add modal start here-->
    <div class="modal custmodal fade" id="AddGRPMModal" aria-hidden="true" data-dismiss="modal">
        <div class="modal-dialog" role="document" style="width: 400px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">Global Resource Pool Manager</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="" id="hdn_GRPmngr" value="" />
                    <div class="form-group row">
                        <label class="required">Manager</label>
                        <%-- <% CommonFunctions.HTMLControls.DrawComboBox("CboManager", "usp_Whizible2_Sel_tbl_PM_Employee_Medium",,, "class='form-control'", True,, ) %>--%>
                        <% CommonFunctions.HTMLControls.DrawComboBox("CboManager", "Select 0,'' ",,, "class='form-control'",,, True) %>
                    </div>
                    <div class="form-group row">
                        <div class="custom_chckbox">
                            <input id="AddGBPMCheck1" name="AddGBPMCheck1" class="clAddGBPMCheck1" type="checkbox" checked="checked">
                            <label for="AddGBPMCheck1">Is Primary Responsible</label>
                        </div>
                    </div>
                    <div class="text-center">
                        <button class="btn borderbtn" data-dismiss="modal">Close</button>
                        <button class="btn btnyellow" onclick="SaveManagerDetails(0);">Save</button>
                        <button class="btn btnyellow" id="btnSaveManagerDetails" onclick="SaveManagerDetails(1);">Save And Add</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Add modal end here-->
    <div class="modal custmodal GrpSavefilter_filter fade" id="GrpSavefilter" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">Save Filter As</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cancelsaveapply()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="GrpSavefilterfilterbox" class="box-panel">

                        <div class="box-body graybg">
                            <div class="form-group mb-0">
                                <div class="row">
                                    <div class="col-md-12 row">
                                        <label class="control-label col-md-4 p-0 text-right">Filter Name :</label>
                                        <span class="col-md-8">
                                            <% CommonFunctions.HTMLControls.DrawTextBox("txtGRPFilterName", "txtGRPFilterName", "form-control",, maxLength:=100) %>
                                            <div class="btnrow">
                                                <button data-dismiss="modal" class="btn btnyellow pull-left savefilter" id="btnSaveFilter" onclick="SaveGRPFilterDetails()">Save</button>
                                                <button data-dismiss="modal" class="btn canclesaveasbtn borderbtn pull-right" onclick="cancelsaveapply()">Cancel</button>
                                            </div>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="clearfix"></div>

                </div>
            </div>
        </div>
    </div>

    <div class="modal custmodal fade" id="DeleteConfirmGRPMModal" aria-hidden="true" data-dismiss="modal">
        <div class="modal-dialog" role="document" style="width: 400px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">Delete Confirmation</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <strong>Note:</strong>  Manager with Primary Responsible can not be deleted.
                    </div>
                    <div class="form-group row">
                        Are you sure, you want to delete the selected records?
                    </div>

                    <div class="text-right">
                        <button class="btn btnyellow" onclick=" DeleteGrpManagerAfterConfirm()">Yes</button>
                        <button class="btn borderbtn" data-dismiss="modal">No</button>
                    </div>

                </div>
            </div>
        </div>
    </div>

     <%--Commented & Added By Rutuja D. For Filter Delete Issue on on 6 July 2021--%>     
    <div id="deleteConfirmAlert" class="modal fade custmodal in" tabindex="-1" role="dialog" aria-hidden="true" data-dismiss="modal">
                        <div class="modal-dialog ui-draggable">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header ui-draggable-handle">
                                    <button type="button" class="close" data-dismiss="modal">×</button>
                                    <h4 class="modal-title">Delete Confirmation</h4>
                                </div>
                                <div class="modal-body">
                                    <input type="text" id="DFilterID" hidden="hidden" />
                                    <input type="text" id="DFilterName" hidden="hidden" />
                                    <input type="text" id="DIsApplyed" hidden="hidden" />
                                    <p id="deleteConfirmMsg"><center>Are you sure to delete the selected filter?</center></p>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn borderbtn pull-left uncheckbtn" data-dismiss="modal">No</button>
                                    <button class="btn btnyellow" data-toggle="modal" data-original-title="" data-dismiss="modal" title="" onclick="confirmDelete()">Yes</button>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                   </div>    
     <%--End of Commented & Added By Rutuja D. For Filter Delete Issue on on 6 July 2021--%>
    

    <script src="../../../Whizible2.0/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jqueryUI js -->
    <script src="../../../Whizible2.0/plugins/jQueryUI/jquery-ui.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap-select.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap.min.js"></script>

    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/dist/js/jquery.dataTables.min.js"></script>
    <!--chart js-->
    <script src="../../../Whizible2.0/plugins/chartjs/Chart.min.js"></script>
    <!--datatable_js-->
    <script src="../../../Whizible2.0/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="../../../Whizible2.0/plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../../../Plugins/alertify/alertify.min.js"></script>
    <script src="../../../Whizible2.0/dist/js/dataTables.paginate.info.js" type="text/javascript"></script>
    <script src="../../../Whizible2.0/dist/js/dataTables.scrollResize.min.js" type="text/javascript"></script>
    <!--daterangepicker-->
    <script src="../../../Whizible2.0/dist/js/moment.min.js"></script>

    <!--autofilter-->
    <script src="../../../Whizible2.0/dist/js/autocomplete/tabcomplete.min.js"></script>
    <script src="../../../Whizible2.0/dist/js/autocomplete/livefilter.min.js"></script>
    <script src="../../../Whizible2.0/dist/js/autocomplete/bootstrap-select-autocomplete.js"></script>

    <script src="../../../Whizible2.0/dist/js/loadingoverlay.min.js"></script>
    <script src="../../../Whizible2.0/dist/js/loadingoverlay_progress.js"></script>
    <!--style-custome-->
    <script src="../../../Whizible2.0/dist/js/issues_custom.js"></script>

    <script>
        var noOfRowsPerPage = 10;
        var DeleteRecord = "Please select at least one record to delete.";
        var NoDataFound = "No data found.";
        var CurrentGRPTabObject = { Details: 'false', GrpManager: 'false', RoleGraph: 'false' };
        $("[data-toggle='tooltip'], [data-toggle='collapse'], [data-toggle='dropdown']").tooltip();


        function editResource() {
            //alert(id);
            //document.getElementById('hdn_GRPmngr').val(id);
            //var GRPname = document.getElementById('hdn_GRPmngr').val();
            //alert("GRPname", GRPname);
            //$(".dataTables_scrollBody").css("height", "auto!important");
            //used for disable grid 
            $(".GRPtblwraps .dataTables_scrollBody, .backbtn, .filter, .paginate_button").addClass("DisableContent").parent().css("cursor", "not-allowed");

            $(".Resourcedetailpanel").show();
            $('html,body').animate({
                scrollTop: $(".Resourcedetailpanel").offset().top -= 60
            }, 'fast');
            $('#GrpPollManagerTab').click()
        }

        $('#tblGlobalResourcePoolManager').on('click', '.clGRPEditManager', function () {
            var isCheckOrNOt = "No";
            CurrentGRPTabObject = { Details: 'false', GrpManager: 'false', RoleGraph: 'false' };
            var $row = $(this).closest("tr");
            var hiddenGRPManagerID = $row.find("#hdn_GRPmanagerId").val();
            $('#hdnGRP_MangerIDTab').val(hiddenGRPManagerID);
            FillBGManager(hiddenGRPManagerID)
            $tds = $row.find("td");

            $.each($tds, function (index, obj) {

                var hiddenGRPUniqueID = $(this).find("#hdnGRP_UniqueID").val();
                var isResposible = $row.find('#hdn_GRPYesNo').val();
                if (hiddenGRPManagerID != 'undefined' && hiddenGRPManagerID != null) {

                    //$(".selectpicker #CboManager").val(hiddenGRPManagerID);
                    $("#CboManager").val(hiddenGRPManagerID);
                    // $('#CboManager').attr("disabled", true);
                    //$('#btnSaveManagerDetails').attr("disabled", true);
                    //alert("hiddenBGMUniqueID" + hiddenBGMManagerID);
                    //alert($("#CboManager").val());
                }
                if (hiddenGRPUniqueID != 'undefined' && hiddenGRPUniqueID != null) {
                    $("#hdnGRP_UniqueIDTab").val(hiddenGRPUniqueID);
                    //$('select[name^="CboBgManager"] option[value=' + hiddenBGMManagerID+']').attr("selected", "selected");

                }
                if (isResposible == "Yes") {
                    $('#AddGBPMCheck1').prop('checked', true);
                }
                else {
                    $('#AddGBPMCheck1').prop("checked", false);
                    //alert('jjKK');
                }

                $('#AddGRPMModal').modal('show');
            });



        });

        function cancledetailpanel() { }

        function GRPEditManager() {

        }
        $(".GBPdetalilink").click(function () {

            $(this).closest('tr').addClass('rowhiglight');
        });

        $('.canceldetailpanel').click(function () {
            $('table tr').removeClass('rowhiglight');
            $(".Resourcedetailpanel").hide();
            $(".GRPtblwraps .dataTables_scrollBody, .backbtn, .filter, .paginate_button").removeClass("DisableContent").parent("div").css("cursor", "auto");
            CurrentGRPTabObject = { Details: 'false', GrpManager: 'false', RoleGraph: 'false' };
        });

        var strUrl = '';
        var DeleteConfirm = "Are you sure, you want to delete the selected records?";
        var blnAddAccess = '<%= m_blnAddAccess%>';
        var blnEditAccess = '<%= m_blnEditAccess%>';
        var blnDeleteAccess = '<%= m_blnDeleteAccess%>';
        var blnViewAccess = '<%= m_blnViewAccess%>';
        var SessionLoginType = '<%= Session("LoginType") %>';
        var SessionEmployeeId = '<%= Session("intUserId") %>';
        var tableRisk = '';
        var tableHistoryRisk = '';
        var tablePlanRisk = '';
        var tableEarlyWarningRisk = '';
        var tableDocumentRisk = '';
        var tableMatrixRisk = '';
        var blnCreateContingencyTask = false;
        var RoleID = '<%= Session("intPostID") %>';
        var UserName = '<%= Session("strUserName") %>';
        var TagID = '<%= m_TagId%>';

        var currentFilterID = 0;
        var currentDefaultFilterID = 0;
        var savedFilterName = ""
        var currentappliedfilter = 0;
        var currentappliedfilterclause = '';
        $(document).ready(function () {
            strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>';
            CurrentGRPTabObject = { Details: 'false', GrpManager: 'false', RoleGraph: 'false' };
            if (blnAddAccess == "False") {
                $("#AddGRP").addClass("clsShowHide");
                $('#btnSaveManagerDetails').attr("disabled", true);

            }
            else {
                $("#AddGRP").removeClass("clsShowHide");
                $('#btnSaveManagerDetails').attr("disabled", false);
            }
            if (blnDeleteAccess == "False") {
                $("#DeleteGRP").addClass("clsShowHide");
            }
            else {
                $("#DeleteGRP").removeClass("clsShowHide");
            }
            if (blnViewAccess == "True") {
                GetMyGRPFilter(0);
                if (currentDefaultFilterID > 0) {
                    ApplySavedFilter(currentDefaultFilterID, 2);

                } else {
                    GetGlobalResourcePool(null);
                    FilterNotApplied();
                }
            } else {
                window.location.href = "../../NewAPI/Resources/UnauthorizePage.aspx";
            }
        });


        function GRPEnableManagerlist() {
            $('#CboManager').attr("disabled", false);
            $('#btnSaveManagerDetails').attr("disabled", false);
            $('#CboManager').val("");
            $('#AddGBPMCheck1').prop('checked', false);
            FillBGManager(0);
        }

        function LoadPagination(data) {
            //var businessGroupTable;
            $.fn.DataTable.ext.pager.numbers_length = 5;
            $('#GRPtbl').dataTable({
                "dtat": data,
                "bFilter": false,
                "retrieve": true,
                "fixedHeader": true,
                "scrollX": true,
                "scrollY": '100',
                "scrollResize": true,
                "scrollcollapse": true,

                //"scrollY": 'auto',
                // "autoWidth": false,
                // "bSort":true,
                //   "bPaginate": true,
                //"pageLength": 15,
                //"bInfo": false, //hide paging info
                //"pagingType": "full_info",   //full_numbers
                "iDisplayLength": noOfRowsPerPage,
                "lengthChange": false,
                "searching": false,
                "destroy": true,
                //"language": {
                //    "emptyTable": "No data available in table",
                //    "zeroRecords":    "No matching records found",
                //    "paginate": {
                //        //"first": "<<",
                //        //"previous": "<",
                //        //"next": ">",
                //        //"last": ">>",
                //        "info": "_START_ - _END_ of _TOTAL_",
                //        "infoEmpty":"0 - 0 of 0",                    
                //    },
                //    "bInfo": true,
                //    "infoEmpty": "0 - 0 of 0",
                //  },
                //  "dom": '<"pull-right top"p >rt<"clear">',
            });

        }

        setTimeout(function () {
            $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
        }, 0);

        function resizeSection() {
            var tblheight = $(window).height();
            $('.GRPtblwraps .dataTables_scrollBody').css({ 'height': tblheight - 240, "overflow-y": "auto" });

            var tblheight = $(window).height();
            $('.Resourcedetailpanel').css({ 'height': tblheight - 80 });
        }
        $(window).on("load resize scroll", function (e) {
            resizeSection(this);
            setTimeout(function () {
                $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
            }, 0);
        });




        $("#filterpanel").on("show.bs.collapse", function () {
            $(".clearalllink").css("display", "inline-block");
        });
        $("#filterpanel").on("hide.bs.collapse", function () {
            $(".clearalllink").hide();
        });

        //check and uncheck checkbox
        // Check or Uncheck All checkboxes
        $(".chckHead").change(function () {
            var checked = $(this).is(':checked');
            if (checked) {
                $(".chcktbl").each(function () {
                    $(this).prop("checked", true);
                });
            } else {
                $(".chcktbl").each(function () {
                    $(this).prop("checked", false);
                });
            }
        });

        // Changing state of CheckAll checkbox
        $(".chcktbl").click(function () {

            if ($(".chcktbl").length == $(".chcktbl:checked").length) {
                $(".chckHead").prop("checked", true);
            } else {
                $(".chckHead").removeAttr("checked");
            }

        });


        function checkUncheck() {
            //alert(123);
            //alert($(".chcktbl").length);
            //alert($(".chcktbl:checked").length);
            if ($(".chcktbl").length == $(".chcktbl:checked").length) {
                $(".chckHead").prop("checked", true);
            } else {
                $(".chckHead").removeAttr("checked");
            }
        }

        //Resource by Rolls chart
        var GrpChart;
        function PlotRoleGraph(LabelList, ColorList, DataList) {
            var Grpctx = document.getElementById("RRChart").getContext('2d');
            if (GrpChart) BgChart.destroy();
            GrpChart = new Chart(Grpctx, {
                type: 'pie',
                data: {
                    labels: LabelList,
                    datasets: [{
                        backgroundColor: ColorList,
                        data: DataList,
                    }]
                },
                options: {
                    legend: {
                        position: 'left',
                        align: "start",
                    }
                }
            });
        }

        function GetGlobalResourcePool(GrpFilterParms) {
            var strHTML = "";
            var strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>';
            StartLoader("#bodyGlobal-Resource");
            $.ajax({
                url: strUrl + '/api/RM_GlobalResourcePool/GetGlobalResourcePool',
                type: "POST",
                data: JSON.stringify(GrpFilterParms),
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    var MyGlobalResourcePools = data;

                    $.each(MyGlobalResourcePools, function (index, obj) {
                        strHTML += '<tr><td class="text-left"> ' + obj.GlobalResourcePoolCode + ' </td> <td class="text-left"> <a href="javascript:;" class="BGdetalilink" onclick="editResource(this)"</a>' + obj.GlobalResourcePoolName + ' </td><input type="hidden" name="hdnGRP_GlobalResourcePoolID" id="hdnGRP_GlobalResourcePoolID" value= ' + obj.GlobalResourcePoolID + '></td></tr>';
                        // $("#tblBusinessGroups bodyBusiness-group").append(row);
                        //console.log("strHTML", strHTML);
                    });
                    $('#GRPtbl').dataTable().fnDestroy();
                    $("#tblGlobalResourcePool").html(strHTML);
                    LoadPagination(data);
                    StopAjaxLoader("#bodyGlobal-Resource");
                },
                // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                //error: function (err) {
                //    console.log(err);
                //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                //    StopAjaxLoader("#bodyGlobal-Resource");
                //}
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                    StopAjaxLoader("#bodyGlobal-Resource");
                },
                // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                

            })

        }
        function ShowGRPManager() {
            if (CurrentGRPTabObject != null && CurrentGRPTabObject.GrpManager == 'false') {
                var GResPoolID = $("#hdnGRP_GlobalResourcePoolID").val();
                // alert(GResPoolID);
                GetGlobalResourcePoolManager(GResPoolID);
                CurrentGRPTabObject.GrpManager = 'true';
            }
        }

        function GetGlobalResourcePoolManager(GlobalResourcePoolID) {
            $("#hdnGRP_UniqueIDTab").val(0);
            $("#hdnGRP_UniqueID").value = 0;
            $("#hdnGRP_UniqueIDTab").value = 0;

            //console.log("aaa",GlobalResourcePoolID);
            var GRPmngrParsms = { GlobalResourcePoolID: GlobalResourcePoolID };
            var strHTML = "";
            var strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>';
            StartLoader("#bodyGlobal-Resource");
            $.ajax({
                url: strUrl + '/api/RM_GlobalResourcePool/GetGlobalResourcePoolManager',
                type: "POST",
                data: JSON.stringify(GRPmngrParsms),
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    var MyGlobalResourcePoolsManager = data;
                    //console.log("data", data);
                    if (MyGlobalResourcePoolsManager.length > 0) {
                        $.each(MyGlobalResourcePoolsManager, function (index, obj) {
                            var strIsPrimaryResponsible = '';
                            if (obj.IsPrimaryResponsible === true) {
                                strIsPrimaryResponsible = 'Yes'
                            } else {
                                strIsPrimaryResponsible = 'No'
                            }
                            if (blnEditAccess == "True") {
                                strHTML += '<tr><td class="text-center"><a href="javascript:;"  class="clGRPEditManager" onclick="GRPEditManager(this)"</a> <input type="hidden" name="hdn_GRPmanagerId" id="hdn_GRPmanagerId" value= ' + obj.ManagerID + '><input type="hidden" name="hdnGRP_UniqueID" id="hdnGRP_UniqueID" value= ' + obj.UniqueID + '>' + obj.Manager + ' </td> <td class="text-center"><input type="hidden" name="hdn_GRPYesNo" id="hdn_GRPYesNo" value= ' + strIsPrimaryResponsible + '>' + strIsPrimaryResponsible + ' </td><td><input onclick="checkUncheck()" class="chcktbl chkGRPManager custom_chckbox" type="checkbox" style="width:18px; height:18px"></td> </tr>';
                            } else {
                                strHTML += '<tr><td class="text-center"><input type="hidden" name="hdn_GRPmanagerId" id="hdn_GRPmanagerId" value= ' + obj.ManagerID + '><input type="hidden" name="hdnGRP_UniqueID" id="hdnGRP_UniqueID" value= ' + obj.UniqueID + '>' + obj.Manager + ' </td> <td class="text-center"><input onclick="checkUncheck()" type="hidden" name="hdn_GRPYesNo" id="hdn_GRPYesNo" value= ' + strIsPrimaryResponsible + '>' + strIsPrimaryResponsible + ' </td><td><input class="chcktbl chkGRPManager custom_chckbox" type="checkbox" style="width:18px; height:18px"></td> </tr>';

                            }
                            //console.log("strHTML", strHTML);
                            // $("#tblBusinessGroups bodyBusiness-group").append(row);
                        });
                    }
                    else {
                        strHTML += '<tr><td class="text-center" colspan="6">' + NoDataFound + '</td></tr>';
                    }
                    //$('#GRPtblmain').dataTable().fnDestroy();
                    $("#tblGlobalResourcePoolManager").html(strHTML);
                    //LoadPaginationForGRPmanager(data);
                    StopAjaxLoader("#bodyGlobal-Resource");
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue 
                        //console.log(thrownError);
                        //alertify.set('notifier', 'position', 'top-right');
                        //alertify.error(xhr.responseJSON.Message);
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                        // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                    }
                    StopAjaxLoader("#bodyGlobal-Resource");
                }
            })

        }

        function SaveManagerDetails(isFromSaveAndclick) {
            var managerID = $("#hdnGRP_MangerIDTab").val();
            var newManagerID = $("#CboManager").val();
            if (newManagerID.length > 0 && newManagerID > 0) {
                var uniqueID = $("#hdnGRP_UniqueIDTab").val();
                var gRPId = $("#hdnGRP_GlobalResourcePoolID").val();

                var isPrimaryResponsible = $("#AddGBPMCheck1").is(":checked");
                var manager = {
                    UniqueID: uniqueID > 0 ? uniqueID : 0,
                    GlobalResourcePoolID: gRPId,
                    ManagerID: uniqueID > 0 ? managerID : newManagerID,
                    NewManagerID: newManagerID,
                    IsPrimaryResponsible: isPrimaryResponsible
                };
<%--            var strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>';--%>
                $.ajax({
                    url: strUrl + '/api/RM_GlobalResourcePool/SaveGRPManagerDetails',
                    method: 'Post',
                    data: JSON.stringify(manager),
                    dataType: 'json',
                    //async: false,
                    contentType: "application/json;charset-utf=8",

                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                    },
                    success: function (data) {
                        CurrentGRPTabObject.GrpManager = 'false';
                        ShowGRPManager();
                        CurrentGRPTabObject.GrpManager = 'true';

                        if (isFromSaveAndclick == 0) {
                            if (data == "Manager already exist") {
                                alertify.set('notifier', 'position', 'top-right');
                                alertify.error(data);
                                // $('#CboManager').val("");
                                $('#AddGRPMModal').modal('show');
                            } else {
                                alertify.set('notifier', 'position', 'top-right');
                                alertify.success(data);
                                $('#AddGRPMModal').modal('hide');
                            }


                        }
                        else {
                            if (data == "Manager already exist") {
                                alertify.set('notifier', 'position', 'top-right');
                                alertify.error(data);
                                //$('#AddGRPMModal').modal('show');
                            }
                            else {
                                alertify.set('notifier', 'position', 'top-right');
                                alertify.success(data);
                                $('#CboManager').val("");
                                $('#AddGBPMCheck1').prop('checked', false);
                            }

                        }
                        //if (isFromSaveAndclick == 1) {
                        //    $('#CboManager').val("");
                        //    $('#AddGBPMCheck1').prop('checked', false);
                        //}
                        //StopAjaxLoader("#bodyGlobal-Resource");
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        if (ajaxOptions == "error") {
                            // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                            //console.log(thrownError);
                            //alertify.set('notifier', 'position', 'top-right');
                            //alertify.error(xhr.responseJSON.Message);
                            if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                                window.open("../../../Default.aspx", "_top");
                            } else {
                                window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                            }
                            // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                        }
                        else if (xhr.statusText == "Created" || xhr.statusText == "Updated") {
                            CurrentGRPTabObject.GrpManager = 'false';
                            ShowGRPManager();
                            CurrentGRPTabObject.GrpManager = 'true';
                            //StopAjaxLoader("#bodyGlobal-Resource");
                        }
                        else {
                            alertify.set('notifier', 'position', 'top-right');
                            alertify.error(thrownError);

                        }
                        ///window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                        StopAjaxLoader("#bodyGlobal-Resource");
                        if (isFromSaveAndclick == 0) {
                            $('#AddGRPMModal').modal('hide');
                        }
                    }
                })
            } else {
                //$('#AddBGMModal').modal('show');
                $("#CboManager").focus();
                alertify.set('notifier', 'position', 'top-right');
                alertify.error("Please select Manager");
            }

        }
        function GetGetMaximumItemsToShowInList() {
            // StartLoader("#bodyGlobal-Resource");
            $.ajax({
                url: strUrl + '/api/RM_GlobalResourcePool/GetMaximumItemsToShowInList',
                type: "POST",
                data: JSON.stringify(),
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    noOfRowsPerPage = data;
                    //alert(noOfRowsPerPage);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        //Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue 
                        //console.log(thrownError);
                        //alertify.set('notifier', 'position', 'top-right');
                        //alertify.error(xhr.responseJSON.Message);
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                        // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                    }
                    else {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.error(thrownError);
                    }


                }
            })

        }



        function GetSelectedGRPResources() {
            var selectedGRPUniqueId = '';
            $('#tblGlobalResourcePoolManager').find('tr').each(function () {
                var row = $(this);
                if (row.find('input[type="checkbox"]').is(':checked')) {
                    selectedGRPUniqueId += row.find('#hdnGRP_UniqueID').val() + ',';
                    //console.log("selectedGRPUniqueId", selectedGRPUniqueId);
                }
            });
            if (selectedGRPUniqueId.length > 0) {
                selectedGRPUniqueId = selectedGRPUniqueId.substring(0, selectedGRPUniqueId.length - 1);
            }
            return selectedGRPUniqueId;
        }
        function DeleteGRPManager() {
            var isSelectedResource = GetSelectedGRPResources();
            if (isSelectedResource.length > 0) {
                $('#DeleteConfirmGRPMModal').modal('show');

            } else {
                alertify.set('notifier', 'position', 'top-right');
                alertify.error(DeleteRecord);
                return false;
            }
        }

        function DeleteGrpManagerAfterConfirm() {
            var isSelectedResource = GetSelectedGRPResources();
            $.ajax({
                url: strUrl + '/api/RM_GlobalResourcePool/DeleteGRPManager',
                type: "POST",
                data: JSON.stringify(isSelectedResource),
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    StartLoader("#bodyGlobal-Resource");
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    if (data != "") {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.success(data);
                    }

                    StopAjaxLoader("#bodyGlobal-Resource");
                    CurrentGRPTabObject.GrpManager = 'false';
                    ShowGRPManager();
                    CurrentGRPTabObject.GrpManager = 'true';
                    $('#DeleteConfirmGRPMModal').modal('hide');
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                        //console.log(thrownError);
                        //alertify.set('notifier', 'position', 'top-right');
                        //alertify.error(xhr.responseJSON.Message);
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                        // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                    }
                    else if (xhr.statusText == "OK") {  //200
                        CurrentGRPTabObject.GrpManager = 'false';
                        ShowGRPManager();
                        CurrentGRPTabObject.GrpManager = 'true';
                        $('#DeleteConfirmBGMModal').modal('hide');
                        //alertify.set('notifier', 'position', 'top-right');
                        // alertify.notify("Deleted");
                    }
                    //else {
                    //    alertify.set('notifier', 'position', 'top-right');
                    //    alertify.notify(thrownError);
                    //    StopAjaxLoader("#bodyBusiness-group");
                    //}

                    ///window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                    StopAjaxLoader("#bodyGlobal-Resource");
                    $('#DeleteConfirmGRPMModal').modal('hide');
                }
            })
        }


        function ShowGraph() {

            if (CurrentGRPTabObject.RoleGraph == "false") {
                GetGRPResourceRoleGraph();
                CurrentGRPTabObject.RoleGraph = 'true';
            }
        }

        if (CurrentGRPTabObject.RoleGraph == 'false') {
            function GetGRPResourceRoleGraph() {
                CurrentGRPTabObject.RoleGraph = 'true';
                var strHTML = "";
                var strHTML = "";
                StartLoader("#bodyGlobal-Resource");
                $.ajax({
                    url: strUrl + '/api/RM_GlobalResourcePool/GetGResourceRoleGraph',
                    type: "POST",
                    contentType: "application/json;charset-utf=8",
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                    },
                    success: function (data) {
                        var GResourcesGraph = data;
                        if (GResourcesGraph.length > 0) {
                            StopAjaxLoader("#bodyGlobal-Resource");
                            //console.log(GResourcesGraph);
                            PlotRoleGraph(GResourcesGraph[0]['LstLabel'], GResourcesGraph[0]['LstColor'], GResourcesGraph[0]['LstData'])
                        } else {
                            PlotRoleGraph(0, 0, 0);
                            alertify.set('notifier', 'position', 'top-right');
                            alertify.error("There is no details available.");
                            StopAjaxLoader("#bodyGlobal-Resource");
                        }
                    },
                    // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                    //error: function (err) {
                    //    console.log(err);
                    //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                    //    StopAjaxLoader("#bodyGlobal-Resource");
                    //}
                    error: function (xhr, ajaxOptions, thrownError) {
                        if (ajaxOptions == "error") {
                            if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                                window.open("../../../Default.aspx", "_top");
                            } else {
                                window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                            }
                        }
                        StopAjaxLoader("#bodyGlobal-Resource");
                    },
                    // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                

                })
            }
        }



        //Fil bg manager on add and edit (with level changed mang)
        function FillBGManager(EmpID) {
            var strHTML = "";
            var objManagerID = { ManagerID: EmpID }
            $.ajax({
                url: strUrl + '/api/RM_BusinessGroup/GetToFillBGManagers',
                type: "POST",
                data: JSON.stringify(objManagerID),
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    //$("#cboOPRFilterLocationID").empty();
                    strHTML += "<option value='0'></option>";
                    $.each(data, function (index, obj) {
                        strHTML += ('<option value=' + obj.EmployeeID + ' >' + obj.UserName + '</option>');
                    })
                    $("#CboManager").html(strHTML);
                    $("#CboManager").val(EmpID);

                },
                // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                //error: function (err) {
                //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                //    //StopAjaxLoader("#bodyBusiness-group");
                //}
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                },
                // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
            })
        }
        //fILTER
        function GenerateGRPBasicFilterQuery(module, filterField) {
            try {
                var strqtext = "";
                for (var i = 0; i < filterField.length; i++) {
                    var strvalue = '';
                    var strOp = $('#cbo' + module + 'Filter' + filterField[i]).val();
                    // var strOp = $('#cbo' + module + 'Filter' + filterField[i] + ' option:selected').val();
                    //alert($("#txt" + module + "Filter" + filterField[i]));
                    strvalue = $("#txt" + module + "Filter" + filterField[i]).val();

                    // strvalue = $("#txtBGFilterBgGroupName").val();
                     //Added By Chetan M on 28 July 2021 For IssueID = 29339
                    strvalue = strvalue.replace(/"/g, '""');
                    //End of Added By Chetan M on 28 July 2021 For IssueID = 29339
                    if (strvalue != "" && strvalue != undefined && strvalue != "0") {

                        if (strqtext != "") strqtext += " AND ";
                        if (strOp == "Contains") {

                            strqtext += filterField[i] + " LIKE ";
                            //strqtext += " ''%" + strvalue + "%''";
                             //Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                            //strqtext += ' "%' + strvalue + '%"';
                            if (strvalue.indexOf('_') > -1 || strvalue.indexOf('%') > -1) {
                               // strqtext += ' "%`' + strvalue + 
                                strvalue = strvalue.replace(/%/g, "`%");
                                strvalue = strvalue.replace(/_/g, "`_");
                                strqtext += ' "%' + strvalue + '%"';
                                strqtext += ' escape "`"';
                            } else {
                                strqtext += ' "%' + strvalue + '%"';
                            }
                            //End of Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                        }
                        else if (strOp == "Ends With") {
                            strqtext += filterField[i] + " LIKE ";
                            // strqtext += " ''%" + strvalue + "''";
                            //Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                            //strqtext += ' "%' + strvalue + '"';
                            if (strvalue.indexOf('_') > -1 || strvalue.indexOf('%') > -1) {
                                //strqtext += ' "%`' + strvalue + '"';
                                strvalue = strvalue.replace(/%/g, "`%");
                                strvalue = strvalue.replace(/_/g, "`_");
                                strqtext += ' "%' + strvalue + '"';
                                strqtext += ' escape "`"';
                            } else {
                                strqtext += ' "%' + strvalue + '"';
                            }
                            //End of Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                        }
                        else if (strOp == "Exact Word") {
                            strqtext += filterField[i] + " = ";
                            //strqtext += " ''" + strvalue + "''";
                            strqtext += ' "' + strvalue + '"';
                        }
                        else if (strOp == "Not Contains") {
                            strqtext += filterField[i] + " ";
                            //strqtext += " NOT LIKE ''%" + strvalue + "%''";
                            //Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                            //strqtext += ' NOT LIKE "%' + strvalue + '%"';
                            if (strvalue.indexOf('_') > -1 || strvalue.indexOf('%') > -1) {
                                strvalue = strvalue.replace(/%/g, "`%");
                                strvalue = strvalue.replace(/_/g, "`_");
                                strqtext += ' NOT LIKE "%' + strvalue + '%"';
                                strqtext += ' escape "`"';
                            } else {
                                strqtext += ' NOT LIKE "%' + strvalue + '%"';
                            }
                            //End of Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                        }
                        else if (strOp == "Starts With") {
                            strqtext += filterField[i] + " LIKE ";
                            // strqtext += " ''" + strvalue + "%''";
                            //Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                            //strqtext += ' "' + strvalue + '%"';
                            if (strvalue.indexOf('_') > -1 || strvalue.indexOf('%') > -1) {
                                strvalue = strvalue.replace(/%/g, "`%");
                                strvalue = strvalue.replace(/_/g, "`_");
                                 strqtext += ' "' + strvalue + '%"';
                                strqtext += ' escape "`"';
                            } else {
                                strqtext += ' "' + strvalue + '%"';
                            }
                            //End of Commented & Added By Chetan M on 28 July 2021 For IssueID = 29339
                        }
                        else {

                            strqtext += filterField[i] + " ";
                            if ($.isNumeric(strvalue) == false) {
                                strqtext += strOp + " ''" + strvalue + "''";
                            }
                            else {
                                //strqtext += strOp + " " + strvalue + "";
                                strqtext += strOp + ' "' + strvalue + '"';
                            }
                        }
                    }
                }

                strqtext = strqtext.replace('Over', '[Over]')
                strqtext = strqtext.replace(/'/g, "''");
                //strqtext = strqtext.replace(/"/g, "''");
                return strqtext;
            }
            catch (ex) {
                //alert(ex.message);
            }
        }
        function setfiltervalues(QueryText) {

            var currWhereClause = QueryText.toString().trim();

            currValue = currWhereClause.toString().trim();
            if (currValue.substring(currValue.length - 1) == ")") {
                currValue = currValue.substring(0, currValue.length - 1);
            }
            if (currValue.substring(0, 1) == "(") {
                currValue = currValue.substring(1);
            }
            currWhereClause = currValue;

            if (currWhereClause.indexOf("NOT LIKE") != -1) {
                currWhereClause = currWhereClause.replace("NOT LIKE", "notlike");
            }

            var str = currWhereClause;

            var regex = /'[^"]+'|[^\s]+/g;
            result = str.match(regex);

            var str = result.toString();
            var arr = str.match(/('.*?'|[^',\s]+)(?=\s*,|\s*$)/g);
            //var arr = str.match(/(\([^\)]+\)|\S+|\s+)/);
            //var arr = str.match(/('.*?'|[^',\s]+[^(.*?),\s]+)(?=\s*,|\s*$)/g);
            for (var i = 0; i < arr.length; i++) {
                //alert(arr[i]);
            }

            var arrFields = currWhereClause.split(" ");
            arrFields = str.match(/('.*?'|[^',\s]+)(?=\s*,|\s*$)/g);
            if (arrFields[0] == "GlobalResourcePoolCode") {
                setFilterOpComboFieldValue(currWhereClause, arrFields, "cboGRPFilterGlobalResourcePoolCode", "txtGRPFilterGlobalResourcePoolCode");
            }
            if (arrFields[0] == "GlobalResourcePoolName") {
                setFilterOpComboFieldValue(currWhereClause, arrFields, "cboGRPFilterGlobalResourcePoolName", "txtGRPFilterGlobalResourcePoolName");
            }
        }
        function setFilterComboValue(fieldName, fieldValue, flag) {
            //if (flag == undefined) {
            //    $("#" + fieldName).removeClass("selectpicker");
            $("#" + fieldName).val(fieldValue);
            //    $("#" + fieldName).addClass("selectpicker");
            //    $('.selectpicker').selectpicker('refresh');
            //}
            //if (flag == "class") {
            //    $("." + fieldName).removeClass("selectpicker");
            //    $("." + fieldName).val(fieldValue);
            //    $("." + fieldName).addClass("selectpicker");
            //    $('.selectpicker').selectpicker('refresh');
            //}
        }
        function setFilterOpComboFieldValue(currWhereClause, arrFields, OpComboName, ValueComboName) {
            if (arrFields[1] == "LIKE" && currWhereClause.indexOf("%'") != -1 && currWhereClause.indexOf("'%") != -1) {
                setFilterComboValue(OpComboName, "Contains");

            }
            if (arrFields[1] == "notlike") {
                setFilterComboValue(OpComboName, "Not Contains");
            }

            if (arrFields[1] == "=") {
                setFilterComboValue(OpComboName, "Exact Word");
            }

            if (arrFields[1] == "LIKE" && currWhereClause.indexOf("%'") != -1 && currWhereClause.indexOf("'%") == -1) {
                setFilterComboValue(OpComboName, "Starts With");
            }

            if (arrFields[1] == "LIKE" && currWhereClause.indexOf("%'") == -1 && currWhereClause.indexOf("'%") != -1) {
                setFilterComboValue(OpComboName, "Ends With");
            }

            var currValue = arrFields[2].replace("'%", "");
            currValue = currValue.replace("%'", "");
            currValue = currValue.toString().trim();
            if (currValue.substring(currValue.length - 1) == "'") {
                currValue = currValue.substring(0, currValue.length - 1);
            }
            if (currValue.substring(0, 1) == "'") {
                currValue = currValue.substring(1);
            }

            //$("#" + ValueComboName).val(currValue);
             //Commented & added by mahesh on  27 july 2021
            if (currValue == "") {
                $("#" + ValueComboName).val("'")
            } else {
                $("#" + ValueComboName).val(currValue);
            }
        }

        function ClearFilterDetails(flag) {
            if ($("#cboGRPFilterGlobalResourcePoolCode").val() != "Contains") {
                setFilterComboValue("cboGRPFilterGlobalResourcePoolCode", "Contains");
            }
            if ($("#txtGRPFilterGlobalResourcePoolCode").val() != "") {
                $("#txtGRPFilterGlobalResourcePoolCode").val("");
            }
            if ($("#txtGRPFilterGlobalResourcePoolName").val() != "") {
                $("#txtGRPFilterGlobalResourcePoolName").val("");
            }
            if ($("#cboGRPFilterGlobalResourcePoolName").val() != "Contains") {
                setFilterComboValue("cboGRPFilterGlobalResourcePoolName", "Contains");
            }
            $('#txtGRPFilterName').val('');
            savedFilterName = "";

            if (flag == "") {
                $('*[id*=RiskselproOne_]').each(function () {

                    $(this).removeAttr("checked");
                });
            }

        }
        function clearTooltip() {
            $('body').tooltip({
                selector: '[data-toggle="tooltip"], [title]:not([data-toggle="popover"])',
                trigger: 'hover',
                container: 'body'
            }).on('click mousedown mouseup', '[data-toggle="tooltip"], [title]:not([data-toggle="popover"])', function () {
                $('[data-toggle="tooltip"], [title]:not([data-toggle="popover"])').tooltip('destroy');
            });
        }

        function FilterApplied() {
            $(".mainclearalllink").removeClass("clsShowHide");
            $(".filter >  button").addClass("clsFilterHighlight");
        }

        function FilterNotApplied() {
            $(".mainclearalllink").addClass("clsShowHide");
            $(".filter >  button").removeClass("clsFilterHighlight");
            $('#AdvanceFilterIcon').attr("aria-expanded", false);
        }
        function BindBasicFilters(qtext, module) {
            ClearBasicFilter(module);
            var isAnd = qtext.indexOf(' AND ');
            if (isAnd > 0) {
                var rowsAnd = qtext.split(' AND ');
                for (i = 0; i < rowsAnd.length; i++) {
                    BindBasicFilterValues(rowsAnd[i], module);
                }
            }
            else {
                BindBasicFilterValues(qtext, module);
            }
        }

        function BindBasicFilterValues(qtext, module) {
            //debugger
            var field = qtext.substr(0, qtext.indexOf(' '));
            var op = orgop = "";
            var val = valstr = "";

            var opstr = qtext.substr(qtext.indexOf(' '), qtext.length).trim();
            var opchar = opstr.substr(0, 1);
            if (opchar == "N" || opchar == "L") {
                if (opchar == "N") {
                    op = "Not Contains";
                    orgop = "NOT LIKE";
                    valstr = opstr.substr(orgop.length, opstr.length).trim();
                    val = valstr.substr(valstr.indexOf('%') + 1, valstr.length - 4);
                }
                if (opchar == "L") {
                    orgop = "LIKE";
                    valstr = opstr.substr(orgop.length, opstr.length).trim();
                    if (valstr.indexOf('%') == 1) {
                        if (valstr.substr(2, valstr.length).indexOf('%') > 0) {
                            op = "Contains";
                            val = valstr.substr(valstr.indexOf('%') + 1, valstr.length - 4);
                        }
                        else {
                            op = "Ends With";
                            val = valstr.substr(valstr.indexOf('%') + 1, valstr.length - 3);
                        }
                    }
                    else {
                        op = "Starts With";
                        val = valstr.substr(1, valstr.length - 3);
                    }
                }
            }
            else {
                op = opstr.substr(0, opstr.indexOf(' '));
                valstr = opstr.substr(op.length, opstr.length).trim();
                val = valstr.substr(1, valstr.length - 2);
            }
            if (op == '=') {
                var cbo = "cbo" + module + "Filter" + field;
                if ($("#" + cbo + " option[value='" + op + "']").length == 0) {
                    op = "Exact Word"
                }
            }
            $('#cbo' + module + 'Filter' + field).val(op).change();
            $('#txt' + module + 'Filter' + field).val(val).change();
        }
        function OpenBasicFilter() {
            //Start Script for edit basic filter           
            $(".stackbasicfilter").addClass("active");
            $(".cust_tabpanel .keep-inside-clicks-open").removeClass("open");
            //End Script for edit basic filter
        }
        $(".mainclearalllink").click(function () {
            $(".filter").removeClass("active");
            //$('.filterpanel').collapse('toggle');                

            FilterNotApplied();
            $(".filter").removeClass("active");
            if ($('.filterpanel').hasClass("in")) {
                $('.filterpanel').removeClass("in");
            }
            $(".clsHideTooltip").each(function () {
                $(this).attr("data-original-title", "Apply filter");
            });
            $('[data-toggle="tooltip"]').tooltip();

            fltPersonResponsible = "";
            currentappliedfilter = 0;
            currentFilterID = 0;
            currentappliedfilterclause = "";
            ClearFilterDetails("");
            GetGRPDetails(null);
        });

        function ApplyFlter() {
            currentFilterID = 0;
            //if ($('#txtGRPFilterGlobalResourcePoolCode').val() == "" && $('#txtGRPFilterGlobalResourcePoolName').val() == "") {
            //    alertify.set('notifier', 'position', 'top-right');
            //    alertify.error('Enter at least one filter value');
            //} else {
            var filter = "";
            //if (filterwhereclause != 'undefined' && filterwhereclause != null) {
            var AllBgFilter = ["GlobalResourcePoolCode", "GlobalResourcePoolName"];
            //var isActiveFilter = $('#chkGrpFilterIsActive').is(":checked");
            var filterWhereClause2 = GenerateGRPBasicFilterQuery("GRP", AllBgFilter);
            //var savwww = filterWhereClause2.toString().replace(/\''/g, "'");
            filterWhereClause = filterWhereClause2.replace(/"/g, "\'");
            //Commented & Added By Rutuja D. on 19 July 2021 For IssueID=27067
            //filter = { UniqueID: '0', IsActive: 'false', GRPWhereClause: encodeURI(filterWhereClause) }
            filter = { UniqueID: '0', IsActive: 'false', GRPWhereClause: encodeURIComponent(filterWhereClause) }
            //End of Commented & Added By Rutuja D. on 19 July 2021 For IssueID=27067
            FilterApplied();
            //}

            //SaveBGFilterDetails();
            GetGlobalResourcePool(filter);
            alertify.set('notifier', 'position', 'top-right');
            alertify.success("Filter applied successfully.");

        }
        function cancelsaveapply() {
            if (currentFilterID == 0 || currentFilterID == null || currentFilterID == undefined || currentFilterID == "") {
                $('#txtGRPFilterName').val("");
            }
        }

        function GetGRPDetails(whereClause) {
            var filter = "";
            if (whereClause != null) {
                // var whereClauseFormated = whereClause.replace(/'/g, "\''");
                //Commented & Added By Rutuja D. on 19 July 2021 For IssueID=27067
                //filter = { UniqueID: '0', IsActive: 'true', GRPWhereClause: encodeURI(whereClause) };
                filter = { UniqueID: '0', IsActive: 'true', GRPWhereClause: encodeURIComponent(whereClause) };
                //End of Commented & Added By Rutuja D. on 19 July 2021 For IssueID=27067
            }
            GetGlobalResourcePool(filter);
            GetMyGRPFilter(0);
        }
        function checkFiltervalidationForGRP() {
            var GRPCode = $("#txtGRPFilterGlobalResourcePoolCode").val() == "" ? null : $("#txtGRPFilterGlobalResourcePoolCode").val();
            var GRPName = $("#txtGRPFilterGlobalResourcePoolName").val() == "" ? null : $("#txtGRPFilterGlobalResourcePoolName").val();
            //alert(GRPCode+ ","+ GRPName);
            if ((GRPCode == null || GRPCode == 'undefined') && (GRPName == null || GRPName == 'undefined')) {
                alertify.set('notifier', 'position', 'top-right');
                alertify.error('Please select at least one filter');
                $('#GrpSavefilter').modal('hide');
            }
            else {
                $('#GrpSavefilter').modal('show');
            }
        }
        var savedFilterName = "";
        function SaveGRPFilterDetails() {
            //alert("HJHJDF");
            var fltFilterName = $("#txtGRPFilterName").val();
            //debugger;
            //$('#BgSavefilter').modal('show');
            // $("#btnSaveFilter").removeAttr("data-dismiss");
            if (fltFilterName == "") {
                //$('#BgSavefilter').modal('show');
                $("#btnSaveFilter").removeAttr("data-dismiss");
                alertify.set('notifier', 'position', 'top-right');
                alertify.error('Please enter filtername');
                //$('#BgSavefilter').modal('show')

                $("#txtGRPFilterName").focus();

                //return false
            }
            else {
                var filterExists = 0;
                //if (savedFilterName == "") {
                //    filterExists = ExistGRPFilter(fltFilterName);
                //    $("#btnSaveFilter").removeAttr("data-dismiss");
                //    $('#GrpSavefilter').modal('show');
                //}

                //if (filterExists == 0) {
                //    $("#btnSaveFilter").attr("data-dismiss", "modal");
                var AllBgFilter = ["GlobalResourcePoolCode", "GlobalResourcePoolName"];
                //var isActiveFilter = 'True';/// $('#chkBgFilterIsActive').is(":checked");
                var filterWhereClause;
                var filterWhereClause2 = GenerateGRPBasicFilterQuery("GRP", AllBgFilter);
                // var isActiveFilter = $('#chkBgFilterIsActive').is(":checked");
                //filterWhereClause2 += "AND Active=" + ' "' + isActiveFilter + '"';
                filterWhereClause = filterWhereClause2.replace(/"/g, "\'");

                var paramFilterID = 0;
                paramFilterID = currentFilterID;

                //if (currentFilterID != 0) {
                //    if (fltFilterName != savedFilterName) {
                //        paramFilterID = 0;
                //    }
                //}

                var paramFlag = 0;
                if (paramFilterID == 0) {
                    paramFlag = 0;
                }
                else {
                    paramFlag = 1;
                }

                var Parameters = {
                    TagID: encodeURI(TagID),
                    ProjectID: null,
                    EmployeeID: encodeURI(SessionEmployeeId),
                    FilterName: encodeURI(fltFilterName),
                    LoginType: encodeURI(SessionLoginType),
                    CreatedBy: encodeURI(UserName),
                    WhereClause: encodeURIComponent(filterWhereClause),
                    Flag: encodeURI(paramFlag),
                    FilterID: encodeURI(paramFilterID)
                }

                $.ajax({
                    url: encodeURI(strUrl) + '/api/RM_MyFilter/SaveMyFilter',

                    method: 'Post',
                    data: JSON.stringify(Parameters),
                    dataType: "json",
                    async: false,
                    contentType: "application/json",  /*;charset-utf=8*/
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                    },
                    success: function (data) {

                        if (data == "Filter name already exist") {
                            // alert(1);
                            alertify.set('notifier', 'position', 'top-right');
                            alertify.error(data);
                            $("#btnSaveFilter").removeAttr("data-dismiss");
                            // $('#OuSavefilter').modal('show');
                            // currentFilterID = 0;
                        }
                        else {
                            if (data != undefined && data != "") {
                                currentFilterID = data;
                                currentappliedfilter = currentFilterID;
                            }
                            $('#GrpSavefilter').modal('hide');
                            //getRiskDetails(currentselectedProjectID, 0, "", "saveapply", "");
                            GetMyGRPFilter(0);
                            ApplyFlter();
                            FilterApplied();

                            savedFilterName = fltFilterName;
                            $("#txtGRPFilterName").val('');
                            //clearTooltip();
                            // ClearFilterDetails("");
                        }


                    },
                    // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                    //error: function (xhr, errorThrown) {
                    //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + xhr + "";
                    //},
                    error: function (xhr, ajaxOptions, thrownError) {
                        if (ajaxOptions == "error") {
                            if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                                window.open("../../../Default.aspx", "_top");
                            } else {
                                window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                            }
                        }
                    },
                    // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                });
                //}
            }
        }
        function GetMyGRPFilter(flag) {
            var Parameters = {
                ProjectID: null,
                TagID: encodeURI(TagID),
                LoginType: encodeURI(SessionLoginType),
                EmployeeID: encodeURI(SessionEmployeeId)
            }

            $.ajax({
                url: encodeURI(strUrl) + '/api/RM_MyFilter/GetMyFilters',
                method: 'POST',
                data: JSON.stringify(Parameters),
                dataType: "json",
                async: false,
                contentType: "application/json",  /*;charset-utf=8*/
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    var strHTML = "";
                    var defaultFilterId = 0;
                    $("#MyFiltersdropdown").empty();
                    if ($("#MyFiltersdropdown").hasClass("dropdown-menu")) {

                    }
                    else {
                        $("#MyFiltersdropdown").addClass("dropdown-menu");
                    }

                    if (data.length != 0) {

                        for (var i = 0; i < data.length; i++) {
                            var ObjMyFilter = data[i];
                            strHTML += "<li>";
                            if (ObjMyFilter.SetDefault === true) {
                                defaultFilterId = ObjMyFilter.FilterId;
                                currentDefaultFilterID = defaultFilterId;

                                strHTML += "<label class='customradio'>";

                                strHTML += "<input class='myfilter_selectprocheckbox' data-toggle='tooltip' data-placement='bottom' id='" + ObjMyFilter.FilterId + "' type='radio' name='project2' onclick='SetDefaultFilter(this.id,&quot;default&quot;)' checked='checked'>";
                                strHTML += "<span data-toggle='tooltip' data-placement='right' title='Remove Default filter' class='checkmark'></span>";
                                strHTML += "</label>";

                            }
                            else {
                                strHTML += "<label class='customradio'>";
                                strHTML += "<input class='myfilter_selectprocheckbox' data-toggle='tooltip' data-placement='bottom' id='" + ObjMyFilter.FilterId + "' type='radio' name='project2' onclick='SetDefaultFilter(this.id,&quot;&quot;)'>";
                                strHTML += "<span data-toggle='tooltip' data-placement='right' title='Set Default filter' class='checkmark'></span>";
                                strHTML += "</label>";
                            }

                            strHTML += "<label class=''>";
                            strHTML += "<span for='project2' class='radiotextsty filtername'>" + ObjMyFilter.FilterName + "</span>";
                            strHTML += "</label>";

                            strHTML += "<div class='custom_chckbox_markblue'>";

                            var blnApply = false;
                            if (currentappliedfilter != 0 && flag != 3) {
                                if (currentappliedfilter == ObjMyFilter.FilterId) {
                                    blnApply = true;
                                }
                            }

                            if (ObjMyFilter.SetDefault == "True") {
                                strHTML += "<div class='custom_chckbox_markblue'>";

                                if (currentappliedfilter != 0 && flag != 3) {
                                    if (blnApply == true) {
                                        strHTML += "<input id='RiskselproOne_" + ObjMyFilter.FilterId + "' checked='' type='checkbox' name='' >";
                                        strHTML += "<label class='clsHideTooltip' data-toggle='tooltip' data-container='body' data-placement='bottom' title='Applied filter' for='RiskselproOne_" + ObjMyFilter.FilterId + "' id='" + ObjMyFilter.FilterId + "' onclick='ApplySavedFilter(this.id,3)'></label>";
                                    }
                                    else {
                                        strHTML += "<input id='RiskselproOne_" + ObjMyFilter.FilterId + "' type='checkbox' name='' >";
                                        strHTML += "<label class='clsHideTooltip' data-toggle='tooltip' data-container='body' data-placement='bottom' title='Apply filter' for='RiskselproOne_" + ObjMyFilter.FilterId + "' id='" + ObjMyFilter.FilterId + "' onclick='ApplySavedFilter(this.id)'></label>";
                                    }
                                }
                                else {
                                    strHTML += "<input id='RiskselproOne_" + ObjMyFilter.FilterId + "' checked='' type='checkbox' name='' >";
                                    strHTML += "<label class='clsHideTooltip' data-toggle='tooltip' data-container='body' data-placement='bottom' title='Applied filter' for='RiskselproOne_" + ObjMyFilter.FilterId + "' id='" + ObjMyFilter.FilterId + "' onclick='ApplySavedFilter(this.id)'></label>";
                                }

                                strHTML += "</div>";
                            }
                            else {
                                strHTML += "<div class='custom_chckbox_markblue'>";
                                if (blnApply == true) {
                                    strHTML += "<input id='RiskselproOne_" + ObjMyFilter.FilterId + "' checked='' type='checkbox' name=''>";
                                    strHTML += "<label class='clsHideTooltip' data-toggle='tooltip' data-container='body' data-placement='bottom' title='Applied filter' for='RiskselproOne_" + ObjMyFilter.FilterId + "' id='" + ObjMyFilter.FilterId + "' onclick='ApplySavedFilter(this.id,3)'></label>";
                                }
                                else {
                                    strHTML += "<input id='RiskselproOne_" + ObjMyFilter.FilterId + "' type='checkbox' name=''>";
                                    strHTML += "<label class='clsHideTooltip' data-toggle='tooltip' data-container='body' data-placement='bottom' title='Apply filter' for='RiskselproOne_" + ObjMyFilter.FilterId + "' id='" + ObjMyFilter.FilterId + "' onclick='ApplySavedFilter(this.id)'></label>";
                                }
                            }

                            strHTML += "<span onclick='OpenBasicFilter()' class='edit_filter'>";

                            strHTML += "<i data-toggle='tooltip' data-container='body' data-placement='bottom' title='Edit filter' id='" + ObjMyFilter.FilterId + "' class='fas fa-pencil-alt' onclick='EditFilter(this.id);'></i>";

                            strHTML += "</span>";

                            strHTML += "<span>";
                            if (blnApply == true) {
                                //strHTML += "<i data-toggle='tooltip' data-container='body' data-placement='bottom' title='Delete filter' id='" + ObjMyFilter.FilterId + "' class='far fa-trash-alt' onclick='DeleteFilter(this.id,3);'></i>";
                                strHTML += "<i data-toggle='tooltip' data-container='body' data-placement='bottom' title='Delete filter' id='" + ObjMyFilter.FilterId + "' class='far fa-trash-alt' onclick=btnDeleteFilter(this.id,&quot;" + escape(ObjMyFilter.FilterName.replace(/'/g, "''")) + "&quot;,3)></i>";
                                //End of Commented & Added By Rutuja D. For Filter Delete Issue on on 6 July 2021
                            }
                            else {
                                //strHTML += "<i data-toggle='tooltip' data-container='body' data-placement='bottom' title='Delete filter' id='" + ObjMyFilter.FilterId + "' class='far fa-trash-alt' onclick='DeleteFilter(this.id);'></i>";
                                strHTML += "<i data-toggle='tooltip' data-container='body' data-placement='bottom' title='Delete filter' id='" + ObjMyFilter.FilterId + "' class='far fa-trash-alt' onclick=btnDeleteFilter(this.id,&quot;" + escape(ObjMyFilter.FilterName.replace(/'/g, "''")) + "&quot;)></i>";
                                //End of Commented & Added By Rutuja D. For Filter Delete Issue on on 6 July 2021
                            }

                            strHTML += "</span>";

                            strHTML += "</div>";

                            strHTML += "</li>";

                        }

                        $("#MyFiltersdropdown").html(strHTML);
                        if (strHTML != "" && defaultFilterId != 0 && flag != 0 && flag != 3) {
                            ApplySavedFilter(defaultFilterId, 1);
                        }

                        $("#MyFiltersdropdown").removeClass("clsShowHide");
                    }
                    else {
                        $("#MyFiltersdropdown").addClass("clsShowHide");
                        $("#MyFiltersdropdown").removeClass("dropdown-menu");
                    }
                },
                // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                //error: function (xhr, errorThrown) {
                //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + xhr + "";
                //},
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                },
                // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
            });
            clearTooltip();
        }

        function ExistGRPFilter(filtername) {

            var isFilterExists = 0;
            var Parameters = {
                FilterName: encodeURI(filtername),
                TagID: encodeURI(TagID),
                ProjectID: null,
                EmployeeID: encodeURI(SessionEmployeeId),
            }

            $.ajax({
                url: encodeURI(strUrl) + '/api/RM_MyFilter/ExistMyFilter',
                method: 'POST',
                data: JSON.stringify(Parameters),
                dataType: "json",
                async: false,
                contentType: "application/json",  /*;charset-utf=8*/
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {

                    if (data == 0) {
                        isFilterExists = 0;
                    }
                    else if (data == 1) {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.error("Filter already exit");
                        isFilterExists = 1;
                    }
                },
                error: function (xhr, errorThrown) {
                    isFilterExists = 1;
                    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + xhr + "";
                },
            });
            return isFilterExists;
        }

        //Delete filter
            //Commented & Added By Rutuja D. For Filter Issue on 7 July 2021
       // function DeleteFilter(FilterID, IsApplyed) {
        function DeleteFilter(FilterID, FilterName, IsApplyed) {
            //End of Commented & Added By Rutuja D. For Filter Issue on 7 July 2021
            $.ajax({
                url: strUrl + '/api/RM_MyFilter/DeleteMyFilter',
                method: 'Post',
                data: JSON.stringify(FilterID),
                dataType: 'json',
                async: false,
                contentType: "application/json",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (result) {
                    if (result == null) {
                        alertify.set('notifier', 'position', 'top-right');
                        //Commented & Added By Rutuja D. For Filter Delete Filter Name Display in Alert on 7 July 2021
                        //  alertify.success('Filter deleted successfully');
                        if (FilterName.indexOf("'") > -1) {
                            FilterName = FilterName.replace(/''/g, "'");
                        }
                        alertify.success("'" + FilterName + "'" + ' Filter deleted successfully');
                        //End of Commented & Added By Rutuja D. For Filter Delete Filter Name Display in Alert on 7 July 2021                        
                        if (IsApplyed == 3) {
                            // var GetGRPWitManager = "ManagerID=" + ' "' + SessionEmployeeId + '"';
                            GetGRPDetails();
                        }
                        ClearFilterDetails("");
                        FilterNotApplied();
                        GetMyGRPFilter(0);
                        currentappliedfilter = 0;
                    }
                },
                // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                //error: function (err) {
                //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + "";
                // }
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                },
                // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
            });
        }

        function EditFilter(FilterID) {
            savedFilterName = "";
            ClearFilterDetails("edit");
            $.ajax({
                url: strUrl + '/api/RM_MyFilter/EditMyFilter',
                method: 'Post',
                data: JSON.stringify(FilterID),
                dataType: 'json',
                async: false,
                contentType: "application/json",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (result) {

                    for (var i = 0; i < result.length; i++) {
                        var ObjFilterDtls = result[i];

                        var currentFilterName = ObjFilterDtls.FilterName;
                        currentFilterID = ObjFilterDtls.FilterId;
                        $("#txtGRPFilterName").val(currentFilterName);
                        savedFilterName = currentFilterName;
                        if (ObjFilterDtls.QueryText.toString().indexOf("AND") != -1) {

                            var arrFields = ObjFilterDtls.QueryText.split("AND");
                            try {
                                for (var i = 0; i < arrFields.length; i++) {
                                    setfiltervalues(arrFields[i]);
                                }
                            }
                            catch (ex) {
                                //alert(ex.message);
                            }
                        }
                        else {
                            var currWhereClause = ObjFilterDtls.QueryText.toString();
                            setfiltervalues(currWhereClause);
                        }//else                        
                    }
                },
                // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                //error: function (err) {
                //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + "";
                //}
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                },
                // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
            });
        }

        //Apply saved filter
        //var currentappliedfilter = 0;
        //var currentappliedfilterclause = '';
        function ApplySavedFilter(FilterID, isDefault) {
            if (isDefault == 3) {
                // var GetGRPWitManager = "ManagerID=" + ' "' + SessionEmployeeId + '"';
                GetGRPDetails();
                GetMyGRPFilter(isDefault);
                FilterNotApplied();
                $('#AdvanceFilterIcon').attr("aria-expanded", false);
            }
            if (isDefault == undefined || isDefault == 2) {
                currentappliedfilter = FilterID;
                $.ajax({
                    url: strUrl + '/api/RM_MyFilter/GetMyWhereClauseOfFilter',
                    method: 'POST',
                    data: JSON.stringify(FilterID),
                    dataType: 'json',
                    async: false,
                    contentType: "application/json",
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                    },
                    success: function (result) {

                        var Querytext = result;
                        if (Querytext != null) {
                            currentappliedfilterclause = Querytext;
                            GetGRPDetails(Querytext);
                        }
                        FilterApplied();
                        if (currentDefaultFilterID > 0) {
                            FilterApplied();
                        }
                        if (currentDefaultFilterID == 0 || isDefault == undefined || isDefault == 2) {
                            GetMyGRPFilter(0);
                        }
                    },
                    //Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                    //error: function (err) {
                    //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + "";
                    //}
                    error: function (xhr, ajaxOptions, thrownError) {
                        if (ajaxOptions == "error") {
                            if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                                window.open("../../../Default.aspx", "_top");
                            } else {
                                window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                            }
                        }
                    },
                    // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                });
            }


        }
        //To set the default filter.
        function SetDefaultFilter(FilterID, flag) {
            var removeDefault = 0;
            if (flag == "default") {
                removeDefault = 1;
            }
            var Parameters = {
                ProjectID: null,
                LoginType: encodeURI(SessionLoginType),
                EmployeeID: encodeURI(SessionEmployeeId),
                TagID: encodeURI(TagID),
                FilterID: FilterID,
                Flag: removeDefault
            }

            $.ajax({
                url: strUrl + '/api/RM_MyFilter/SetMyDefaultFilter',
                method: 'Post',
                data: JSON.stringify(Parameters),
                dataType: 'json',
                async: false,
                contentType: "application/json",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (result) {
                    alertify.set('notifier', 'position', 'top-right');
                    //alert(removeDefault);
                    if (removeDefault == 0) {
                        //alertify.success('Success');
                        // ApplySavedFilter(FilterID, 2);
                        ApplySavedFilter(FilterID, 2);
                        alertify.success('Filter Is Successfully Set As Default!');
                        $('#AdvanceFilterIcon').attr("aria-expanded", true);
                        FilterApplied();
                    }
                    else {
                        //alertify.success('Default');
                        //FilterNotApplied();
                        ApplySavedFilter(FilterID, 3);
                        alertify.success('Default Filter Is Successfully Removed!');
                        currentappliedfilter = 0;
                        $('#AdvanceFilterIcon').attr("aria-expanded", false);
                        FilterNotApplied();
                    }
                    GetMyGRPFilter(0);
                },
                // Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
                //error: function (err) {
                //    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + "";
                //}
                error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message == "Authorization has been denied for this request." || thrownError == "Unauthorized") {
                            window.open("../../../Default.aspx", "_top");
                        } else {
                            window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                },
                // End of Commented & Integrate By Rutuja D. on 8 July 2021 for Session Expired Issue                
            });
        }

        function cancledetailpanel() {

        }

         //Commented & Added By Rutuja D. For Filter Delete Issue on on 6 July 2021
        function btnDeleteFilter(FilterID, FilterName, Flag) {
            FilterName = unescape(FilterName).trim();
            $('#DFilterID').val(FilterID);
            $('#DFilterName').val(FilterName);
            $('#DIsApplyed').val(Flag);
            $('#deleteConfirmAlert').modal('show');
        }

        function confirmDelete() {
            var FilterID = $('#DFilterID').val();
            var FilterName = $('#DFilterName').val();
            var FilterIsApplyed = $('#DIsApplyed').val();
            if (FilterIsApplyed == 3) {
                DeleteFilter(FilterID, FilterName, 3);
            } else {
                DeleteFilter(FilterID, FilterName);
            }
        }
        //End of Commented & Added By Rutuja D. For Filter Delete Issue on on 6 July 2021

    </script>

</body>

</html>
