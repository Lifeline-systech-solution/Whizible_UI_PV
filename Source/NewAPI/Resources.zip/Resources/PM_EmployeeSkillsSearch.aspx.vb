﻿Public Class PM_EmployeeSkillsSearch
    Inherits WebPages.Template.WhizTemplate

    Protected m_PKToken_FromPSDList As String = ""
    Protected m_PKToken_ToPSDList As String = ""

    Public m_AddAccess As Boolean = False
    Public m_DeleteAccess As Boolean = False
    Public m_EditAccess As Boolean = False
    Public m_ViewAccess As Boolean = False

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        MyBase.InitializeResources("Whizible2Resources.Source.Resources.EmployeeSkillsSearch", "Whizible2Resources")
        MyBase.ApplySecurity(True)

        CreateGlobalObject()
        m_PKToken_FromPSDList = CommonFunctions.Security.Token.GetToken("426" + CType(Session("intUserID"), String))

        If (((m_PKToken_FromPSDList = "") And (HttpContext.Current.Session("intUserID").ToString <> "0")) Or (CommonFunctions.Security.Token.ValidateToken("426" + CType(Session("intUserID"), String), m_PKToken_FromPSDList) = False)) Then
            System.Web.HttpContext.Current.Response.Redirect("../../General/CommonPage.aspx?MasterTagID=436")
        End If
    End Sub

    Public Sub CreateGlobalObject()
        Dim objGlobal As WebPages.Template.IGlobal

        MyBase.FillGlobalObject(MyBase.CurrentThreadUICultureID, CommonFunctions.General.GetApplicationKeySetting("UseHashTableForCLCP"))
        objGlobal = MyBase.GlobalObject
        objGlobal.TagID = 436
        Dim objAccess As New WebPages.Template.AccessRights
        objAccess.GetAccess(objGlobal)

        m_AddAccess = objAccess.Add 'If user has AddNew Access
        m_DeleteAccess = objAccess.Delete 'If User has Delete Access
        m_EditAccess = objAccess.Edit 'If user has Edit Access
        m_ViewAccess = objAccess.View 'If user has Edit Access

        If (m_AddAccess = True Or m_EditAccess = True Or m_DeleteAccess = True) Then
            m_ViewAccess = True
        End If
    End Sub


    <System.Web.Services.WebMethod()>
    Public Shared Function GeneratePK_TokenResumePage(ByVal EmployeeID As String) As String

        Dim m_PKToken_FromResumeList As String
        m_PKToken_FromResumeList = CommonFunctions.Security.Token.GetToken("426" + EmployeeID + CType(HttpContext.Current.Session("intUserID"), String))

        Return m_PKToken_FromResumeList
    End Function

    <System.Web.Services.WebMethod()>
    Public Shared Function ValidatePK_TokenResumePage(ByVal EmployeeID As String, ByVal PKToken As String) As Boolean
        Try
            If (((PKToken = "") And (HttpContext.Current.Session("intUserID").ToString <> "0")) Or (CommonFunctions.Security.Token.ValidateToken("426" + EmployeeID + CType(HttpContext.Current.Session("intUserID"), String), PKToken) = False)) Then
                Return False
            Else
                Return True
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function


    'Filter Session Activated
    'Public Function ActivateSession(ByVal data As String) As String
    <System.Web.Services.WebMethod()>
    Public Shared Function ActivateSession(ByVal data As String, ByVal DatatableSelectedID As String) As String
        HttpContext.Current.Session("Activated") = "1"
        HttpContext.Current.Session("SkillData") = data
        HttpContext.Current.Session("DatatableSelectedID") = DatatableSelectedID
        'Return "OK" & "~" & HttpContext.Current.Session("Activated") & "~" & HttpContext.Current.Session("SkillData") & "~" & HttpContext.Current.Session("DatatableSelectedID")
        Return "OK"

    End Function

    'Filter Session Clear
    <System.Web.Services.WebMethod()>
    Public Shared Function ClearSession() As String
        HttpContext.Current.Session("Activated") = ""
        HttpContext.Current.Session("SkillData") = ""
        HttpContext.Current.Session("DatatableSelectedID") = ""
        Return "OK"
    End Function

End Class