﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="HR_ResourceSkill_Summary.aspx.vb" Inherits="PbNIT.HR_ResourceSkill_Summary" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title>Resource</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/jquery-ui.css?v=2"/>
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap.min.css?v=1"/>
    <!-- bootstrap select -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap-select.css?v=2"/>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../Whizible2.0/fontawesome/css/all.css?v=2"/>
    <!-- Theme style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/AdminLTE.min.css?v=2"/>
    <!-- animate css -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/animate.css?v=2"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/dataTables.bootstrap.min.css?v=0"/>
    <!-- custom style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom.css?v=3"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom_project.css?v=3.1"/>
    <!-- media_queries -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/media_queries.css?v=2"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/adavanced_filter.css?v=0.1"/>

    <link href="../../../Whizible2.0/plugins/alertify/css/alertify.min.css" rel="stylesheet" />

    <style type="text/css">
        .alertify-notifier {
        color: #fff;
        background: rgba(217, 92, 92, 0,95);
        text-shadow: -1px -1px 0 rgba(0, 0, 0, 0,5);
    }
        .dataTables_scrollBody thead tr[role="row"] {
            visibility: collapse !important;
        }

        a.clearalllink {
            font-weight: bold;
            margin: 7px 0px 0 8px;
            display: none;
        }

        .filter.pull-right {
            margin: 2px 0 0 8px;
        }

        table tr th {
            vertical-align: middle !important;
        }

            table tr td:last-child .custom_chckbox label:before, table tr th:last-child .custom_chckbox label:before {
                margin-right: 0;
            }

        .notebox {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
        }

        .dropdown-submenu .dropdown-submenu > a:after {
            border-color: transparent transparent transparent #fff;
            border-style: solid;
            border-width: 5px 0 5px 5px;
            content: " ";
            display: block;
            float: right;
            height: 0;
            margin-right: 10px;
            margin-top: 5px;
            width: 0;
        }

        .dropdown-submenu > .dropdown-submenu:hover a:after {
            border-color: transparent transparent transparent #464a4c;
        }

        .filterpanelbody .input-sm button {
            height: 30px;
        }

        table th:first-child, #SkillsummuryTbl tr td:first-child {
            text-align: left !important;
        }

        h5.pgtitle {
            margin: 6px 0 0;
            font-weight: 700;
            color: #4263c1;
            font-size: 16px;
        }

        .notebox {
            font-size: 12px;
            margin-top: 15px;
            margin-bottom: 0;
        }
    </style>

</head>
<body class="hold-transition skin-blue-light sidebar-mini fixed">


    <div class="bgwhite">
        <div class="pt-1 pb-1 graybg">
            <div class="col-sm-12">
                <h5 class="pgtitle pull-left"><%= MyBase.GetResourceString("C_Name") %></h5>
                <div class="dropdown filedownload pull-right" style="margin-top: 5px;">
                    <button class="nostylebtn dropdown-toggle" data-toggle="dropdown"><i data-toggle="tooltip" data-placement="bottom" data-title="Click here to download" class="fas fa-download"></i></button>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('PDF')">
                            <img src="../../../Whizible2.0/dist/img/pdf.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Pdf") %></a>
                        </li>
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('EXCEL')">
                            <img src="../../../Whizible2.0/dist/img/xls.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Xlsx") %></a>
                        </li>
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('XML')">
                            <img src="../../../Whizible2.0/dist/img/xml.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Xml") %></a>
                        </li>
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('TEXT')">
                            <img src="../../../Whizible2.0/dist/img/doc.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Doc") %></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="content pt-1">
            <table id="SkillsummuryTbl" class="table table-bordered" style="width: 100%;">
                <thead>
                    <tr>
                        <th><%= MyBase.GetResourceString("T_HeaderName") %></th>
                        <th width="50">
                            <div class="custom_chckbox">
                                <input id="SkillsumryCheck0" class="chckHead" type="checkbox">
                                <label for="SkillsumryCheck0"></label>
                            </div>
                        </th>
                    </tr>
                </thead>
                 <tbody id="tbodyStageMaster">
                </tbody>
            </table>
            <div class="clearfix"></div>
            <div class="notebox graybg">
                <strong>Note:</strong> Our recommended report format is PDF. Other formats do work in most of the reports, but in some cases output format may not be as good as PDF. This is due to inherent reporting engine problems, which are beyond our control. If you desire we can disable other output formats in your configuration.
            </div>
        </div>
        <div class="clearfix"></div>
    </div>

    <!-- REQUIRED JS SCRIPTS -->
    <!-- jQuery 2.1.4 -->
    <script src="../../../Whizible2.0/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jqueryUI js -->
    <script src="../../../Whizible2.0/plugins/jQueryUI/jquery-ui.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap-select.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap.min.js"></script>

    <script src="../../../Whizible2.0/plugins/alertify/alertify.min.js"></script>

    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/dist/js/jquery.dataTables.min.js"></script>
    <script>
        $("[data-toggle='tooltip'], [data-toggle='collapse'], [data-toggle='dropdown'], [data-toggle='modal']").tooltip();
        var strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>'
        var WebConfigSpecialCharacters = '<%=System.Configuration.ConfigurationManager.AppSettings("SpecialCharactersList").ToString%>'
        alertify.set('notifier', 'position', 'top-right');
        var LoginType = '<%= Session("LoginType") %>';
        var RoleID = '<%= Session("intPostID") %>';
        var UserID = '<%= Session("intUserID") %>';
        var UserName = '<%= Session("strUserName") %>';
        var ProjectId = '<%= Session("intProjectID") %>';
        var ajaxResult;

        $(document).ready(function ()
        {
            //Created by imran 11-11-2021 To Get All Skill List
            GetSkillData();
            //End by imran 11-11-2021
        });

        $('#SkillsummuryTbl').dataTable({
            "scrollY": "30vh",
            "scrollX": true,
            "pageLength": 5,
            "lengthChange": false,
            "bFilter": false,
            "ordering": false,
            "responsive": true,
            "destroy": false,
            "retrieve": true,
            "responsive": true
        });

        setTimeout(function () {
            $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
        }, 0);

        function resizeSection() {
            var tblheight = $(window).height();
            $('.dataTables_scrollBody').css({ 'height': tblheight - 265, "overflow-y": "auto" });

        }

        $(window).on("load resize scroll", function (e) {
            resizeSection(this);
            setTimeout(function () {
                $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
            }, 0);
        });

        $("#filterpanel").on("show.bs.collapse", function () {
            $(".clearalllink").css("display", "inline-block");
        });

        $("#filterpanel").on("hide.bs.collapse", function () {
            $(".clearalllink").hide();
        });

        ////check and uncheck checkbox
        //// Check or Uncheck All checkboxes
        //$(".chckHead").change(function () {
        //    var checked = $(this).is(':checked');
        //    if (checked) {
        //        $(".chcktbl").each(function () {
        //            $(this).prop("checked", true);
        //        });
        //    } else {
        //        $(".chcktbl").each(function () {
        //            $(this).prop("checked", false);
        //        });
        //    }
        //});

        //// Changing state of CheckAll checkbox
        //$(".chcktbl").click(function () {

        //    if ($(".chcktbl").length == $(".chcktbl:checked").length) {
        //        $(".chckHead").prop("checked", true);
        //    } else {
        //        $(".chckHead").removeAttr("checked");
        //    }
        //});
        

        //this use for if uncheck one of the Checkbox then remove check of Select all For OU
        $(document).on('change', '.checkstage', function ()
        {
            var table = $("#SkillsummuryTbl").DataTable();
            var checked = table.rows().nodes().to$().find('input[type="checkbox"].checkstage').length;
            var checked1 = table.rows().nodes().to$().find('input[type="checkbox"].checkstage:checked').length;
            if (checked == checked1) {
                $(".chckHead").prop("checked", true);
            }
            else {
                $(".chckHead").prop("checked", false);
            }
        });

        //Check Or Uncheck All checkBox OU
        $('.chckHead').click(function ()
        {
            var table = $('#SkillsummuryTbl').DataTable();
            if ($(this).prop("checked") == true) {
                var rows1 = table.rows({ 'search': 'applied' }).nodes();
                $('input[type="checkbox"]', rows1).each(function () {
                    this.checked = true;
                });
            }
            else if ($(this).prop("checked") == false) {
                var rows2 = table.rows({ 'search': 'applied' }).nodes();
                $('input[type="checkbox"]', rows2).each(function () {
                    this.checked = false;
                });
            }
        });

        //Created by imran 11-11-2021
        function GetSkillCheckData()
        {
            var table = $('#SkillsummuryTbl').DataTable();
            var rows = table.rows({ 'search': 'applied' }).nodes();
            var MasterIDs = $('input[name=checkstage]:checked', rows).map(function () {
                return this.value;
            }).get().join(',');
            var arrMasterIDs = MasterIDs.split(',');
            return "'" +arrMasterIDs+ "'";
        }
        //End by imran 11-11-2021

        //Created by imran 11-11-2021
        function GetSkillData()
        {
            var strHTML = "";
            var Parameter =
            {
                EmployeeID: 0,                
            }
            var param = JSON.stringify(Parameter);
            var Result = AJAXCallWithResult("/api/RM_ResourceSkillSummary/GetAllSkillSummaryData", param, false);
            for (var i = 0; i < Result.length; i++) {
                var ToolID = Result[i]["ToolID"];
                var Description = Result[i]["Description"];

                strHTML += '<tr>'
                strHTML += '<td>' + Description + '</td>'
                strHTML += '<td>'
                strHTML += '<div class="custom_chckbox">'
                strHTML += '<input id="StageCheck_' + ToolID + '" name="checkstage" class="chcktbl" type="checkbox" value="' + ToolID + '"/>'
                strHTML += '<label for="StageCheck_' + ToolID + '"></label>'
                strHTML += '</div>'
                strHTML += '</td>'
                strHTML += '</tr>'
            }
            $('#SkillsummuryTbl').dataTable().fnDestroy();
            $("#tbodyStageMaster").html('');
            $("#tbodyStageMaster").append(strHTML);
            $("#SkillsummuryTbl").dataTable({
                "scrollY": "30vh",
                "scrollX": true,
                "pageLength": 5,
                "lengthChange": false,
                "bFilter": false,
                "ordering": false,
                "responsive": true,
                "destroy": false,
                "retrieve": true,
                "responsive": true
            });
        }
        //End by imran 11-11-2021

        //Created by imran 11-11-2021
        function ExportInfraDemandInfo(ReportFormat)
        {
            var skillID = GetSkillCheckData();   

            if (skillID == "''")
            {
                var reportParameter = { CheckBoxIDs: "", ReportFormat: ReportFormat }
            }
            else {
                 var reportParameter = { CheckBoxIDs: skillID, ReportFormat: ReportFormat }
            }
            var k = JSON.stringify(reportParameter)
            k = k.replace("[","");
            k = k.replace("]", "");
          
            $.ajax({
                url: strUrl + '/api/RM_ResourceSkillSummary/ExportDocument',
                type: "POST",
                data: k,
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data)
                {
                    if (data == "")
                    {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.error("Records not available to download Report.");
                    }
                    else {
                        window.open("../../CRW/CRW_ReportOutput.aspx?filename=" + data, "_report", "");
                    }
                },               
                 error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message=="Authorization has been denied for this request." || thrownError=="Unauthorized") {
                            window.open("../../../Default.aspx","_top");
                        } else {
                           // window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                }
            })
        }
        //End by imran 11-11-2021

        function AJAXCallWithResult(url, param, async)
        {
            $.ajax({
                url: encodeURI(strUrl) + url,
                type: "POST",
                data: param,
                async: async,
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    ajaxResult = data;
                },
                error: function (err) {
                    console.log(err);
                    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                }
            });
            return ajaxResult;
        }

    </script>
</body>
</html>