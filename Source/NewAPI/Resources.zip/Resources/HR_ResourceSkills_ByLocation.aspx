﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="HR_ResourceSkills_ByLocation.aspx.vb" Inherits="PbNIT.HR_ResourceSkills_ByLocationNew" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Skills (Organization Unit)</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/jquery-ui.css?v=2"/>
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap.min.css?v=1"/>
    <!-- bootstrap select -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap-select.css?v=2"/>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../Whizible2.0/fontawesome/css/all.css?v=2"/>
    <!-- Theme style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/AdminLTE.min.css?v=2"/>
    <!-- animate css -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/animate.css?v=2"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/dataTables.bootstrap.min.css?v=0"/>
    <!-- custom style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom.css?v=3"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom_project.css?v=3.1"/>
    <!-- media_queries -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/media_queries.css?v=2"/>
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/adavanced_filter.css?v=0.1"/>
    <link href="../../../Whizible2.0/plugins/alertify/css/alertify.min.css" rel="stylesheet" />

    <style type="text/css">
        .alertify-notifier {
        color: #fff;
        background: rgba(217, 92, 92, 0,95);
        text-shadow: -1px -1px 0 rgba(0, 0, 0, 0,5);
    }
        .dataTables_scrollBody thead tr[role="row"] {
            visibility: collapse !important;
        }

        a.clearalllink {
            font-weight: bold;
            margin: 7px 0px 0 8px;
            display: none;
        }

        .filter.pull-right {
            margin: 2px 0 0 8px;
        }

        table tr th {
            vertical-align: middle !important;
            padding: 8px !important;
        }

            table tr td:last-child .custom_chckbox label:before, table tr th:last-child .custom_chckbox label:before {
                margin-right: 0;
            }

        .notebox {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
        }

        .dropdown-submenu .dropdown-submenu > a:after {
            border-color: transparent transparent transparent #fff;
            border-style: solid;
            border-width: 5px 0 5px 5px;
            content: " ";
            display: block;
            float: right;
            height: 0;
            margin-right: 10px;
            margin-top: 5px;
            width: 0;
        }

        .dropdown-submenu > .dropdown-submenu:hover a:after {
            border-color: transparent transparent transparent #464a4c;
        }

        .filterpanelbody .input-sm button {
            height: 30px;
        }

        table th:first-child, #SkillOUTbl tr td:first-child, #SkillSelTbl tr td:first-child {
            text-align: left !important;
        }

        h5.pgtitle {
            margin: 6px 0 0;
            font-weight: 700;
            color: #4263c1;
            font-size: 16px;
        }

        .notebox {
            font-size: 12px;
            margin-top: 15px;
            margin-bottom: 0;
        }

        .panel-heading {
            font-weight: 600;
        }

        .panel-default > .panel-heading {
            background: #e7edf0;
        }

        .p-0 {
            padding: 0 !important;
        }

        div.dataTables_wrapper div.dataTables_info {
            float: left;
        }

        .dataTables_paginate {
            margin-top: 5px !important;
        }

        .panel-body {
            padding: 10px;
        }

        @media screen and (min-width: 767px) {
            .dataTables_info {
                padding-top: 30px !important;
            }

            .dataTables_paginate {
                padding-top: 20px !important;
            }
        }
    </style>

</head>
<body class="hold-transition skin-blue-light sidebar-mini fixed">
   
    <div class="bgwhite">
        <div class="pt-1 pb-1 graybg">
            <div class="col-sm-12">
                <h5 class="pgtitle pull-left"><%= MyBase.GetResourceString("C_Caption") %></h5>
                <div class="dropdown filedownload pull-right" style="margin-top: 5px;">
                    <button class="nostylebtn dropdown-toggle" data-toggle="dropdown"><i data-toggle="tooltip" data-placement="bottom" data-title="Click here to download" class="fas fa-download"></i></button>
                    <ul class="dropdown-menu">
                       <li>
                            <a href="#" onclick="ExportInfraDemandInfo('PDF')">
                            <img src="../../../Whizible2.0/dist/img/pdf.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Pdf") %></a>
                        </li>
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('EXCEL')">
                            <img src="../../../Whizible2.0/dist/img/xls.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Xlsx") %></a>
                        </li>
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('XML')">
                            <img src="../../../Whizible2.0/dist/img/xml.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Xml") %></a>
                        </li>
                        <li>
                            <a href="#" onclick="ExportInfraDemandInfo('TEXT')">
                            <img src="../../../Whizible2.0/dist/img/doc.svg" width="18px" ><%= MyBase.GetResourceString("Dwnl_Doc") %></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        
        <div class="content pt-1">
            <div class="row">
                <div class="col-sm-6">
                    <div class="panel panel-default p-0">
                        <div class="panel-heading"><%= MyBase.GetResourceString("C_SelectOrganizationUnit") %></div>
                        <div class="panel-body">
                            <table id="SkillOUTbl" class="table table-bordered" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th><%= MyBase.GetResourceString("T_HeaderOU") %></th>
                                        <th width="50">
                                            <div class="custom_chckbox">
                                                <input id="SkillOUCheck0" class="chckHeadOU" type="checkbox">
                                                <label for="SkillOUCheck0"></label>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody id="tbodyOU">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="panel panel-default p-0">
                        <div class="panel-heading"><%= MyBase.GetResourceString("C_SelectSkills") %></div>
                        <div class="panel-body">
                            <table id="SkillSelTbl" class="table table-bordered" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th><%= MyBase.GetResourceString("T_HeaderName") %></th>
                                        <th width="50">
                                            <div class="custom_chckbox">
                                                <input id="SelSkillCheck0" class="chckHead" type="checkbox">
                                                <label for="SelSkillCheck0"></label>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                 <tbody id="tbodySkill">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="clearfix"></div>
               
                <div class="col-sm-12"> <%--Added by imran 12-11-2021 to show Note with proper alignment--%>
                    <div class="notebox graybg">
                        <strong>Note:</strong> Our recommended report format is PDF. Other formats do work in most of the reports, but in some cases output format may not be as good as PDF. This is due to inherent reporting engine problems, which are beyond our control. If you desire we can disable other output formats in your configuration.
                    </div>
                </div><%--End by imran 12-11-2021--%>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
        
    <!-- REQUIRED JS SCRIPTS -->
    <!-- jQuery 2.1.4 -->
    <script src="../../../Whizible2.0/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jqueryUI js -->
    <script src="../../../Whizible2.0/plugins/jQueryUI/jquery-ui.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap-select.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/dist/js/jquery.dataTables.min.js"></script>
    <script src="../../../Whizible2.0/plugins/alertify/alertify.min.js"></script>

    <script>
        $("[data-toggle='tooltip'], [data-toggle='collapse'], [data-toggle='dropdown'], [data-toggle='modal']").tooltip();
        var strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>'
        var WebConfigSpecialCharacters = '<%=System.Configuration.ConfigurationManager.AppSettings("SpecialCharactersList").ToString%>'
        alertify.set('notifier', 'position', 'top-right');
        var LoginType = '<%= Session("LoginType") %>';
        var RoleID = '<%= Session("intPostID") %>';
        var UserID = '<%= Session("intUserID") %>';
        var UserName = '<%= Session("strUserName") %>';
        var ProjectId = '<%= Session("intProjectID") %>';
        var ajaxResult;

        $(document).ready(function ()
        {
            //Created by imran 12-11-2021 To Get All Skill List
            GetSkillData();
            //End by imran 12-11-2021
        });
    
        $('#SkillOUTbl').dataTable({
            "scrollY": "38vh",
            "scrollX": true,
            "pageLength": 5,
            "lengthChange": false,
            "bFilter": false,
            "ordering": false,
            "responsive": true,
            "destroy": false,
            "retrieve": true,
            "responsive": true
        });

        $('#SkillSelTbl').dataTable({
            "scrollY": "38vh",
            "scrollX": true,
            "pageLength": 5,
            "lengthChange": false,
            "bFilter": false,
            "ordering": false,
            "responsive": true,
            "destroy": false,
            "retrieve": true,
            "responsive": true
        });

        setTimeout(function () {
            $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
        }, 0);

        ////check and uncheck checkbox
        //// Check or Uncheck All checkboxes For Skill
        //$(".chckHead").change(function ()
        //{
        //    var checked = $(this).is(':checked');
        //    if (checked)
        //    {
        //        $(".chcktblSkill").each(function ()
        //        {
        //            $(this).prop("checked", true);
        //        });
        //    }
        //    else
        //    {
        //        $(".chcktblSkill").each(function ()
        //        {
        //            $(this).prop("checked", false);
        //        });
        //    }
        //});

        //// Changing state of CheckAll checkbox
        //$(".chcktblSkill").click(function () {

        //    if ($(".chcktblSkill").length == $(".chcktblSkill:checked").length) {
        //        $(".chckHead").prop("checked", true);
        //    } else {
        //        $(".chckHead").removeAttr("checked");
        //    }
        //});


        // //check and uncheck checkbox
        //// Check or Uncheck All checkboxes For OU
        //$(".chckHeadOU").change(function () {
        //    var checked = $(this).is(':checked');
        //    if (checked) {
        //        $(".chcktblOU").each(function () {
        //            $(this).prop("checked", true);
        //        });
        //    } else {
        //        $(".chcktblOU").each(function () {
        //            $(this).prop("checked", false);
        //        });
        //    }
        //});

        //// Changing state of CheckAll checkbox
        //$(".chcktblOU").click(function () {

        //    if ($(".chcktblOU").length == $(".chcktblOU:checked").length) {
        //        $(".chckHead").prop("checked", true);
        //    } else {
        //        $(".chckHead").removeAttr("checked");
        //    }
        //});



        //this use for if uncheck one of the Checkbox then remove check of Select all For OU
        $(document).on('change', '.chcktblOU', function ()
        {
            var table = $("#SkillOUTbl").DataTable();
            var checked = table.rows().nodes().to$().find('input[type="checkbox"].chcktblOU').length;
            var checked1 = table.rows().nodes().to$().find('input[type="checkbox"].chcktblOU:checked').length;
            if (checked == checked1) {
                $(".chckHeadOU").prop("checked", true);
            }
            else {
                $(".chckHeadOU").prop("checked", false);
            }
        });

        //Check Or Uncheck All checkBox OU
        $('.chckHeadOU').click(function ()
        {
            var table = $('#SkillOUTbl').DataTable();
            if ($(this).prop("checked") == true) {

                var rows1 = table.rows({ 'search': 'applied' }).nodes();
                $('input[type="checkbox"]', rows1).each(function () {
                    this.checked = true;
                });
            }
            else if ($(this).prop("checked") == false) {
                var rows2 = table.rows({ 'search': 'applied' }).nodes();
                $('input[type="checkbox"]', rows2).each(function () {
                    this.checked = false;
                });
            }
        });


        ////this use for if uncheck one of the Checkbox then remove check of Select all For Skill
        $(document).on('change', '.chcktblskill', function ()
        {           
            var table = $("#SkillSelTbl").DataTable();
            var checked = table.rows().nodes().to$().find('input[type="checkbox"].chcktblSkill').length;
            var checked1 = table.rows().nodes().to$().find('input[type="checkbox"].chcktblSkill:checked').length;
            if (checked == checked1) {
                $(".chckHead").prop("checked", true);
            }
            else {
                $(".chckHead").prop("checked", false);
            }
        });                      

         //Check Or Uncheck All checkBox OU
        $('.chckHead').click(function ()
        {
            var table = $('#SkillSelTbl').DataTable();
            if ($(this).prop("checked") == true) {
                var rows1 = table.rows({ 'search': 'applied' }).nodes();
                $('input[type="checkbox"]', rows1).each(function () {
                    this.checked = true;
                });
            }
            else if ($(this).prop("checked") == false) {
                var rows2 = table.rows({ 'search': 'applied' }).nodes();
                $('input[type="checkbox"]', rows2).each(function () {
                    this.checked = false;
                });
            }
        });



        //Created by imran 12-11-2021 SkillData
        function GetSkillCheckData()
        {
            var table = $('#SkillSelTbl').DataTable();
            var rows = table.rows({ 'search': 'applied' }).nodes();
            var MasterIDs = $('input[name=checkSkill]:checked', rows).map(function () {
                return this.value;
            }).get().join(',');
            var arrMasterIDs = MasterIDs.split(',');
            return "'" +arrMasterIDs+ "'";
        }
        //End by imran 12-11-2021

        //Created by imran 12-11-2021 LocationData
        function GetLocationCheckData()
        {
            var table = $('#SkillOUTbl').DataTable();
            var rows = table.rows({ 'search': 'applied' }).nodes();
            var MasterIDs = $('input[name=checkOU]:checked', rows).map(function () {
                return this.value;
            }).get().join(',');
            var arrMasterIDs = MasterIDs.split(',');
            return "'" +arrMasterIDs+ "'";
        }
        //End by imran 12-11-2021

        //Created by imran 12-11-2021
        function GetSkillData()
        {
            var strHTML = "";                
            var Result = AJAXCallWithResult("/api/RM_ResourceSkillByLocation/LocationData", "", false);
            for (var i = 0; i < Result.length; i++) {
                var LocationID = Result[i]["LocationID"];
                var Location = Result[i]["Location"];

                strHTML += '<tr>'
                strHTML += '<td>' + Location + '</td>'
                strHTML += '<td>'
                strHTML += '<div class="custom_chckbox">'
                strHTML += '<input id="OUCheck_' + LocationID + '" name="checkOU" class="chcktblOU" type="checkbox" value="' + LocationID + '"/>'
                strHTML += '<label for="OUCheck_' + LocationID + '"></label>'
                strHTML += '</div>'
                strHTML += '</td>'
                strHTML += '</tr>'
            }
            $('#SkillOUTbl').dataTable().fnDestroy();
            $("#tbodyOU").html('');
            $("#tbodyOU").append(strHTML);
            $("#SkillOUTbl").dataTable({
                //Commented and added by imran
                //"scrollY": "30vh",
                "scrollY": "38vh",
                "scrollX": true,
                "pageLength": 5,
                "lengthChange": false,
                "bFilter": false,
                "ordering": false,
                "responsive": true,
                "destroy": false,
                "retrieve": true,
                "responsive": true
            });


            //Fill Skill
            strHTML = "";
            var Parameter =
            {
                EmployeeID: 0,                
            }
            var param = JSON.stringify(Parameter);
            var Result = AJAXCallWithResult("/api/RM_ResourceSkillByLocation/SkillData", param, false);
            for (var i = 0; i < Result.length; i++)
            {
                var ToolID = Result[i]["ToolID"];
                var Description = Result[i]["Description"];

                strHTML += '<tr>'
                strHTML += '<td>' + Description + '</td>'
                strHTML += '<td>'
                strHTML += '<div class="custom_chckbox">'
                strHTML += '<input id="SkillCheck_' + ToolID + '" name="checkSkill" class="chcktblSkill" type="checkbox" value="' + ToolID + '"/>'
                strHTML += '<label for="SkillCheck_' + ToolID + '"></label>'
                strHTML += '</div>'
                strHTML += '</td>'
                strHTML += '</tr>'
            }
            $('#SkillSelTbl').dataTable().fnDestroy();
            $("#tbodySkill").html('');
            $("#tbodySkill").append(strHTML);
            $("#SkillSelTbl").dataTable({
                "scrollY": "38vh",
                "scrollX": true,
                "pageLength": 5,
                "lengthChange": false,
                "bFilter": false,
                "ordering": false,
                "responsive": true,
                "destroy": false,
                "retrieve": true,
                "responsive": true
            });

        }
        //End by imran 12-11-2021

        //Created by imran 12-11-2021
        function ExportInfraDemandInfo(ReportFormat)
        {
            var skillID = GetSkillCheckData();
            var LocationID = GetLocationCheckData();   
            if (skillID == "''" || LocationID=="''")
            {
                alertify.set('notifier', 'position', 'top-right');
                alertify.error("<%= MyBase.GetResourceString("A_OU") %>");
                return;
            }
            var reportParameter = {LocationIDs:LocationID, ReportFormat: ReportFormat,SkillIDs: skillID }
            var k = JSON.stringify(reportParameter)
            k = k.replace("[","");
            k = k.replace("]", "");

            $.ajax({
                url: strUrl + '/api/RM_ResourceSkillByLocation/ExportDocument',
                type: "POST",
                data: k,
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data)
                {
                    if (data == "")
                    {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.error("<%= MyBase.GetResourceString("A_RecordNotFound") %>");
                    }
                    else {
                        window.open("../../CRW/CRW_ReportOutput.aspx?filename=" + data, "_report", "");
                    }
                },               
                 error: function (xhr, ajaxOptions, thrownError) {
                    if (ajaxOptions == "error") {
                        if (xhr.responseJSON.Message=="Authorization has been denied for this request." || thrownError=="Unauthorized") {
                            window.open("../../../Default.aspx","_top");
                        } else {
                           // window.location.href = "../../General/default.aspx.aspx?Mode=AJAXError&Error=" + xhr.responseJSON.Message + ""
                        }
                    }
                }
            })
        }
        //End by imran 12-11-2021

        function AJAXCallWithResult(url, param, async)
        {
            $.ajax({
                url: encodeURI(strUrl) + url,
                type: "POST",
                data: param,
                async: async,
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    ajaxResult = data;
                },
                error: function (err) {
                    console.log(err);
                    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                }
            });
            return ajaxResult;
            }

    </script>

</body>
</html>