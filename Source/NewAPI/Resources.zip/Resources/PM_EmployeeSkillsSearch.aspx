﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="PM_EmployeeSkillsSearch.aspx.vb" Inherits="PbNIT.PM_EmployeeSkillsSearch" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Resource</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/jquery-ui.css?v=2" />
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap.min.css?v=1" />
    <!-- bootstrap select -->
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap-select.css?v=2" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../Whizible2.0/fontawesome/css/all.css?v=2" />
    <!-- Theme style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/AdminLTE.min.css?v=2" />
    <!-- animate css -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/animate.css?v=2" />
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/dataTables.bootstrap.min.css?v=0" />
    <!-- custom style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom.css?v=3" />
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom_project.css?v=3.1" />

    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/adavanced_filter.css?v=0.1" />
    <link href="../../../Whizible2.0/plugins/alertify/css/alertify.min.css" rel="stylesheet" />

    <style type="text/css">
        .divtotal {
            margin-right: -14px;
            margin-top: 7px;
        }

        .spntotal {
            float: right;
        }

        .alertify-notifier {
            color: #fff;
            background: rgba(217, 92, 92, 0,95);
            text-shadow: -1px -1px 0 rgba(0, 0, 0, 0,5);
        }

        .dataTables_scrollBody thead tr[role="row"] {
            visibility: collapse !important;
        }

        a.clearalllink {
            font-weight: bold;
            margin: 7px 0px 0 8px;
            display: none;
        }

        .filter.pull-right {
            margin: 2px 0 0 8px;
        }

        table tr th {
            vertical-align: middle !important;
        }

            table tr td:last-child .custom_chckbox label:before, table tr th:last-child .custom_chckbox label:before {
                margin-right: 0;
            }

        .notebox {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
        }

        .dropdown-submenu .dropdown-submenu > a:after {
            border-color: transparent transparent transparent #fff;
            border-style: solid;
            border-width: 5px 0 5px 5px;
            content: " ";
            display: block;
            float: right;
            height: 0;
            margin-right: 10px;
            margin-top: 5px;
            width: 0;
        }

        .dropdown-submenu > .dropdown-submenu:hover a:after {
            border-color: transparent transparent transparent #464a4c;
        }

        /*Detailpanel*/
        .Resourcedetailpanel {
            margin: 40px 15px 0;
            display: none;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .pgdetailinner {
            padding: 10px;
        }

        .Resourcedetailpanel .tab-pane {
            padding: 20px 0;
        }

        tr.rowhiglight {
            background: #c3dbff;
        }

        .DisableContent {
            pointer-events: none;
            opacity: 0.5;
        }

            .DisableContent:hover {
                cursor: no-drop;
            }

        .dataTables_scrollBody.DisableContent {
            height: auto !important
        }

        ul.nav.nav-tabs.detailsubtabs {
            background: #f5f5f5;
            margin: -11px -11px;
            padding: 10px 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px 4px 0 0;
        }

        .nav.detailsubtabs > li > a:hover, .nav.nav.detailsubtabs > li > a:active, .nav.nav.detailsubtabs > li > a:focus {
            background: #fff;
            color: #1359ac;
        }

        h5.pgtitle {
            margin: 6px 0 0;
            font-weight: 700;
            color: #4263c1;
            font-size: 16px;
        }

        .dblock {
            display: block;
        }

        .mr-5 {
            margin-right: 5px;
        }

        .ml-1 {
            margin-left: 10px;
        }

        .custom_chckbox label:before {
            margin-right: 10px;
        }

        .filterpanelbody > .row > div:nth-child(5n), .filterpanelbody > .row > div:nth-child(6n), .filterpanelbody > .row > div:nth-child(7n) {
            width: 33.33%;
        }

        .srchetbllist tr th {
            width: 25%;
        }

        .d-inline-block {
            display: inline-block !important;
        }

        .custom_radio input[type="radio"] + label span {
            margin: 0 5px;
        }

        .freeztblouter {
            display: none;
        }

        .srchetbllist th, .srchetbllist td {
            text-align: left !important;
        }

        .rsrsnamerow td {
            font-weight: bold;
        }

        .ui-widget-content {
            z-index: 9999 !important;
        }

        /*resumestyle*/
        .content-wrapper {
            background: #eee !important
        }

        .resumecontainer {
            max-width: 860px;
            margin: 0 auto;
            border: 1px solid #ddd;
            box-shadow: 0 1px 4px rgba(0,0,0,0.1);
            background: #fff;
            border-radius: 4px
        }

        .resumeHeader {
            padding: 15px 0;
            border-bottom: 1px solid #eee
        }

        .resumehdright.graybg {
            padding: 15px
        }

        .resumetblTitle {
            background: #4263c1 !important;
            color: #fff !important;
            font-size: 16px;
            font-weight: 400;
            padding: 4px 8px !important
        }

        .CandidateName h4 {
            color: #1359a6
        }

        .ResumeAsignmentDetails {
            display: block;
            text-align: left
        }

        .RProname strong {
            color: #1359ac !important
        }

        .resumebody {
            padding: 15px
        }

        .table-bordered tbody th {
            background: #e7edf0
        }

        .bankrow td {
            padding: 0 !important;
            height: 5px !important;
            border: none !important;
            line-height: 5px !important
        }

        .candidateContctinfo p {
            margin-bottom: 0;
            line-height: 18px;
            text-align: right
        }

            .candidateContctinfo p label {
                width: 100px
            }
        /*resume style end*/
        thead {
            position: sticky;
            top: 0;
        }

        body {
            overflow: hidden;
        }

        #setfilterModal .form-inline label {
            min-width: 120px;
        }

        #setfilterModal .form-inline select, #setfilterModal .form-inline input {
            min-width: 200px;
        }

        #setfilterModal .form-inline {
            margin-bottom: 10px;
        }
    </style>

</head>

<body class="hold-transition skin-blue-light sidebar-mini fixed">

    <div class="bgwhite">

        <div class="container-fluid pt-1 pb-1 mb-1 text-right graybg">
            <h5 class="pgtitle pull-left"><%= MyBase.GetResourceString("C_Search") %></h5>
        </div>


        <div class="container-fluid pt-1 pb-1 text-right">
            <div class="row">
                <div class="col-sm-6 text-left">
                    <div class="d-inline-block">
                        <div class="custom_radio d-inline-block">
                            <input id="Rlistbyrsrs" name="Rgroup1" value="DivEmployeeTable" type="radio" checked="checked" onclick="ListByEmployeeCount()">
                            <label for="Rlistbyrsrs"><span></span></label>
                        </div>
                        <label><%= MyBase.GetResourceString("C_ListByEmployee") %></label>
                    </div>
                    <div class="d-inline-block  ml-1">
                        <div class="custom_radio d-inline-block">
                            <input id="Rlistbyskill" name="Rgroup1" value="SkillTable" type="radio" onclick="ListBySkillCount()">
                            <label for="Rlistbyskill"><span></span></label>
                        </div>
                        <label><%= MyBase.GetResourceString("C_ListBySkill") %></label>
                    </div>
                </div>
                <div class="col-sm-6">
                    <a href="javascript:;" class="btn borderbtn" data-toggle="modal" data-target="#setfilterModal" onclick="setfilterModal()">Set Filter</a>
                    <a id="btnclear" href="javascript:;" class="btn borderbtn" onclick="ClearFilter()">Clear Filter</a>
                    <!--<a href="resource-plan-index.html" class="btn borderbtn backbtn" id="" data-toggle="tooltip" data-placement="bottom" title="Back to Resource Configuration">Back</a>-->
                </div>
            </div>
        </div>

        <div class="content pt-0">

            <div class="table-responsive freeztblouter" id="DivEmployeeTable">
                <table id="srchbyemployeetbl" class="table table-bordered srchetbllist" style="width: 100%;">
                    <thead>
                        <tr>
                            <th class="text-left" width="200"><%= MyBase.GetResourceString("T_Resource") %></th>
                            <th class=""><%= MyBase.GetResourceString("T_Skill") %></th>
                            <th class=""><%= MyBase.GetResourceString("T_Experience") %></th>
                            <th class=""><%= MyBase.GetResourceString("T_Proficiency") %></th>
                        </tr>
                    </thead>
                    <tbody id="ListByEmployee"></tbody>
                </table>
            </div>

            <div class="table-responsive freeztblouter" id="SkillTable">
                <table id="srchbyskilltbl" class="table table-bordered srchetbllist" style="width: 100%;">
                    <thead>
                        <tr>
                            <th class="text-left" width="200"><%= MyBase.GetResourceString("T_Skill") %></th>
                            <th class=""><%= MyBase.GetResourceString("T_Resource") %></th>
                            <th class=""><%= MyBase.GetResourceString("T_Experience") %></th>
                            <th class=""><%= MyBase.GetResourceString("T_Proficiency") %></th>
                        </tr>
                    </thead>
                    <tbody id="ListBySkill"></tbody>
                </table>
            </div>

            <div class="clearfix"></div>
        </div>

        <%--Total Record--%>
        <div class="paginationdiv">
            <%--<div class='buttons col-sm-10 divtotal'> Total Records  <span class="spntotal" id="TotalRecords" style="margin-right: -60px"></span> </div>--%>
            <div class='buttons col-sm-10 pull-left text-left'>Total Records : <span id="TotalRecords"></span></div>
            <div class='buttons col-sm-2 pull-right text-right' id="Pagination">
                <nav aria-label="Page navigation example">
                    <ul class="pagination" style="margin: 0 0;">
                        <li class="page-item" id="btnprevious">
                            <a class="page-link" aria-label="Previous" onclick='PrevList()' title="Previous" id="LinkPrevious">
                                <i class="fas fa-angle-double-left"></i>
                            </a>
                        </li>
                        <li class="page-item" id="btnnext">
                            <a class="page-link" aria-label="Next" onclick='NextList()' title="Next" id="LinkNext">
                                <i class="fas fa-angle-double-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>


        <!--Set Filter modal start here-->
        <div class="modal custmodal fade" id="setfilterModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-dismiss="modal">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id=""><%= MyBase.GetResourceString("C_SetFilter") %></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="graybg p1">

                            <p>
                                Resource must be free by
                                <div class="input-group col-sm-4">
                                    <input id="setfltrDatefield1" type="text" class="form-control" autocomplete="off" />
                                    <span class="input-group-btn">
                                        <button class="btn btncalendar" type="button"><i class="fas fa-calendar-alt"></i></button>
                                    </span>
                                </div>
                            </p>
                            <p>Additional filtering criteria (Note: You may leave them blank)</p>
                            <div class="form-inline">
                                <div class="form-group">
                                    <label><%= MyBase.GetResourceString("C_OrganizationUnit") %></label>
                                    <% CommonFunctions.HTMLControls.DrawComboBox("cboOU", "usp_Sel_PM_LocationList",,, "class='form-control'",,, ) %>
                                </div>
                                <div class="form-group">
                                    <label><%= MyBase.GetResourceString("C_Department") %></label>
                                    <% CommonFunctions.HTMLControls.DrawComboBox("cboDept", "usp_Sel_PM_DepartmentList",,, "class='form-control'",,, ) %>
                                </div>
                            </div>
                            <div class="form-inline">
                                <div class="form-group">
                                    <label><%= MyBase.GetResourceString("C_Role") %></label>
                                    <% CommonFunctions.HTMLControls.DrawComboBox("cboRole", "usp_Sel_tbl_PM_Role",,, "class='form-control'",,, ) %>
                                </div>
                                <div class="form-group">
                                    <label><%= MyBase.GetResourceString("C_Resource") %></label>
                                    <%-- <label>Resource</label>--%>
                                    <% CommonFunctions.HTMLControls.DrawTextBox("txtResourceName", "txtResourceName", "form-control",,,,,,,,,, "autocomplete='Off' maxlength='50'",,, True,,,, True) %>
                                </div>
                            </div>
                            <div class="pt-1 pb-1">
                                <div class="d-inline-block">
                                    <div class="custom_radio d-inline-block">
                                        <input id="setfiltrRadibtn1" name="Rgroup2" value="" type="radio" checked="checked">
                                        <label for="setfiltrRadibtn1"><span></span></label>
                                    </div>
                                    <label><%= MyBase.GetResourceString("C_AtLeastTool") %></label>
                                </div>
                                <div class="d-inline-block">
                                    <div class="custom_radio d-inline-block">
                                        <input id="setfiltrRadibtn2" name="Rgroup2" value="" type="radio">
                                        <label for="setfiltrRadibtn2"><span></span></label>
                                    </div>
                                    <label><%= MyBase.GetResourceString("C_AtLeast") %></label>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <p><%= MyBase.GetResourceString("C_Specifying") %></p>

                        <div class="table-responsive" style="max-height: 300px;">
                            <table class="table table-stripped" id="FilterSkillTbl">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th colspan="2" width="200px"><%= MyBase.GetResourceString("C_MinimumExperienceRequired") %></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                    <tr>
                                        <th><%= MyBase.GetResourceString("T_Skill") %></th>
                                        <th><%= MyBase.GetResourceString("T_Year") %></th>
                                        <th><%= MyBase.GetResourceString("T_Months") %></th>
                                        <th><%= MyBase.GetResourceString("T_Proficiency") %></th>
                                        <th><%= MyBase.GetResourceString("T_CoreCompetencyrequired") %></th>
                                        <th><%= MyBase.GetResourceString("T_Select") %></th>
                                    </tr>
                                </thead>
                                <tbody id="FilterSkill" />
                            </table>
                        </div>

                        <br />
                        <div class="text-center">
                            <button data-dismiss="modal" class="btn borderbtn mr-5"><%= MyBase.GetResourceString("C_Close") %></button>
                            <a href="javascript:;" class="btn borderbtn mr-5" id="btnApplyFilter"><%= MyBase.GetResourceString("C_ApplyFilter") %></a>
                        </div>
                        <div class="clearfix"></div>

                    </div>
                </div>
            </div>
        </div>
        <!--Set Filter modal end here-->

        <!--resume modal start here-->
        <div class="modal custmodal fade" id="ResumeModal" aria-hidden="true" data-dismiss="modal">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="">Resume</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="resumecontainer">
                            <div class="resumeHeader">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-3 text-center">
                                        <figure>
                                            <img id="EmpImg" style="margin: 0 auto;" width="150" class="img-circle img-responsive" alt="" src="../../../Whizible2.0/dist/img/blankprofile.png">
                                        </figure>
                                    </div>

                                    <div class="col-xs-12 col-sm-9">
                                        <div class="resumehdright graybg">
                                            <div class="CandidateName pull-left">
                                                <h4 style="margin-top: 0" id="Empname">John Dawyer</h4>
                                                <span>Business Development Manager</span>
                                            </div>
                                            <div class="candidateContctinfo pull-right">
                                                <p style="margin-bottom: 0">
                                                    <label>Date of Birth : </label>
                                                    <span id="Empdob">09/08/1974</span>
                                                </p>
                                                <p style="margin-bottom: 0">
                                                    <label>Phone No : </label>
                                                    <span id="Empmob">1111 222 3333</span>
                                                </p>
                                                <p style="margin-bottom: 0">
                                                    <label>Email ID : </label>
                                                    <span id="Empemail"><a href="javascript:;"></a>quality05@lifeline-sys.com</span>
                                                </p>
                                            </div>
                                            <div class="clearfix"></div>
                                            <hr style="margin: 10px 0; border-color: #ddd;" />
                                            <p style="margin-bottom: 0;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                                            <!--<ul class="list-group">
                                            <li class="list-group-item">Name!</li>
                                            <li class="list-group-item">Company!</li>
                                            <li class="list-group-item">Job Description! </li>
                                            <li class="list-group-item"><i class="fa fa-phone"></i> Phone no. </li>
                                            <li class="list-group-item"><i class="fa fa-envelope"></i> Email-id </li>
                                        </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="resumebody">
                                <table id="TechSkilltbl" class="table table-stripped table-bordered" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th class="resumetblTitle text-left">Technical Skills</th>
                                            <th class="resumetblTitle text-left"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="ListByTechSkill"></tbody>
                                </table>

                                <table id="CurrentAssignmenttbl" class="table table-stripped table-bordered" style="width: 100%; margin-bottom: 0;">
                                    <thead>
                                        <%--<tr>
                                            <th colspan="5" class="resumetblTitle text-left">Current Assignments</th>
                                        </tr>
                                        <tr class="bankrow">
                                            <td colspan="5">&nbsp;</td>
                                        </tr>--%>
                                        <tr>
                                            <th class="text-left">Project Name</th>
                                            <th>Duration<span>(Years)</span></th>
                                            <th>Team<span>Size</span></th>
                                            <th>Role</th>
                                        </tr>
                                    </thead>
                                    <tbody id="ListByCurrentAssignment"></tbody>
                                    <%--<tbody>
                                        <tr>
                                            <td class="RProname text-left">
                                                <strong>LifeLine Strategy Project (2019-20)</strong>
                                                <span class="ResumeAsignmentDetails">This project is created to conduct weekly review meetings,action items etc</span>
                                            </td>

                                            <td>From 08/05/2019</td>
                                            <td>11</td>
                                            <td>Project Manager Scrum Master</td>
                                        </tr>
                                        <tr>
                                            <td class="RProname text-left">
                                                <strong>LifeLine Strategy Project (2019-20)</strong>
                                                <span class="ResumeAsignmentDetails">This project is created to conduct weekly review meetings,action items etc</span>
                                            </td>

                                            <td>From 08/05/2019</td>
                                            <td>11</td>
                                            <td>Project Manager Scrum Master</td>
                                        </tr>
                                        <tr>
                                            <td class="RProname text-left">
                                                <strong>LifeLine Strategy Project (2019-20)</strong>
                                                <span class="ResumeAsignmentDetails">This project is created to conduct weekly review meetings,action items etc</span>
                                            </td>

                                            <td>From 08/05/2019</td>
                                            <td>11</td>
                                            <td>Project Manager Scrum Master</td>
                                        </tr>
                                        <tr>
                                            <td class="RProname text-left">
                                                <strong>LifeLine Strategy Project (2019-20)</strong>
                                                <span class="ResumeAsignmentDetails">This project is created to conduct weekly review meetings,action items etc</span>
                                            </td>

                                            <td>From 08/05/2019</td>
                                            <td>11</td>
                                            <td>Project Manager Scrum Master</td>
                                        </tr>
                                    </tbody>--%>
                                </table>
                                <br />

                                <div class="text-center">
                                    <button class="btn borderbtn" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!--resume modal end here-->

        <div class="clearfix"></div>
    </div>


    <!-- REQUIRED JS SCRIPTS -->
    <!-- jQuery 2.1.4 -->
    <script src="../../../Whizible2.0/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jqueryUI js -->
    <script src="../../../Whizible2.0/plugins/jQueryUI/jquery-ui.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap-select.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/bootstrap/js/bootstrap.min.js"></script>

    <!-- Bootstrap 3.3.5 -->
    <script src="../../../Whizible2.0/dist/js/jquery.dataTables.min.js"></script>
    <!--chart js-->
    <script src="../../../Whizible2.0/plugins/chartjs/Chart.min.js"></script>
    <script src="../../../Whizible2.0/plugins/alertify/alertify.min.js"></script>


    <script>

        $("[data-toggle='tooltip'], [data-toggle='collapse'], [data-toggle='dropdown']").tooltip();
        var strUrl = '<%=System.Configuration.ConfigurationManager.AppSettings("WebAPIUrl-II").ToString%>'
        var WebConfigSpecialCharacters = '<%=System.Configuration.ConfigurationManager.AppSettings("SpecialCharactersList").ToString%>'
        alertify.set('notifier', 'position', 'top-right');
        var LoginType = '<%= Session("LoginType") %>';
        var RoleID = '<%= Session("intPostID") %>';
        var UserID = '<%= Session("intUserID") %>';
        var UserName = '<%= Session("strUserName") %>';
        var ProjectId = '<%= Session("intProjectID") %>';

        var Activated = '<%= Session("Activated") %>';
        var SkillData = '<%= Session("SkillData") %>';
        var DatatableSelectedID = '<%= Session("DatatableSelectedID") %>';

        //Pagination
        var TotalRecords = 0;
        var intPageNo = 0;
        var SearchRecords = 0;

        //change date format
        var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var uDatepicker = $.datepicker._updateDatepicker;
        $.datepicker._updateDatepicker = function () {
            var ret = uDatepicker.apply(this, arguments);
            var $sel = this.dpDiv.find('select');
            $sel.find('option').each(function (i) {
                $(this).text(months[i]);
            });
            return ret;
        };

        //datepicker
        $('#setfltrDatefield1').datepicker({
            autoclose: true,
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd MM yy'
        });

        var tables = $('.freeztblouter');
        $('input[name="Rgroup1"]').on('change', function () {
            tables.hide();
            //$('.table-responsive').css('height', 'auto');
            $('#' + $(this).val()).show();
        });

        $(document).ready(function () {
            var checked = $('input[name="Rgroup1"]').is(':checked');

            if (checked) {
                $("#DivEmployeeTable").show();
            }
        });


        function resizeSection() {
            //var tblheight = $(window).height();
            //$('.content').css({ 'height': tblheight - 100, "overflow-y": "auto" });

            var tblheight = $(window).height();
            //$('.table-responsive').css({ 'height': tblheight - 100, "overflow-y": "auto" });
            $('.table-responsive').css({ 'height': tblheight - 160, "overflow-y": "auto" });
        }
        $(window).on("load resize 0scroll", function (e) {
            resizeSection(this);

        });


        $("#filterpanel").on("show.bs.collapse", function () {
            $(".clearalllink").css("display", "inline-block");
        });
        $("#filterpanel").on("hide.bs.collapse", function () {
            $(".clearalllink").hide();
        });

        //check and uncheck checkbox
        // Check or Uncheck All checkboxes
        $(".chckHead").change(function () {
            var checked = $(this).is(':checked');
            if (checked) {
                $(".chcktbl").each(function () {
                    $(this).prop("checked", true);
                });
            } else {
                $(".chcktbl").each(function () {
                    $(this).prop("checked", false);
                });
            }
        });

        // Changing state of CheckAll checkbox
        $(".chcktbl").click(function () {

            if ($(".chcktbl").length == $(".chcktbl:checked").length) {
                $(".chckHead").prop("checked", true);
            } else {
                $(".chckHead").removeAttr("checked");
            }

        });


        $(document).ready(function () {
            if (Activated == "" | Activated == null) {
                $("#btnclear").hide();
                intPageNo = 1;
                ListbyEmployee(0, '');
                ListbySkill(0, '');

            }
            else {
                intPageNo = 1;
                setfilterModal();
            }
        });


        //Added by imran 15-11-2021 ListbyEmployee Datatable Fill
        function ListbyEmployee(flag, ResourceIDs) {
            $("#ListByEmployee").html('');

            var strHTML = '';
            if (flag == 0) {
                var ResourceParameters =
                {
                    PageNo: intPageNo,
                    PageSize: 10
                }
                var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/GetListByEmployee", JSON.stringify(ResourceParameters), false);
                var ResultCount = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/TotalCountWithout", "", false);
            }
            else {
                var OU = $("#cboOU").val();
                var Dept = $("#cboDept").val();
                var Role = $("#cboRole").val();
                var Resource = ResourceIDs;
                var FreeByDate = $("#setfltrDatefield1").val();
                var ResourceName = $("#txtResourceName").val();

                if (OU == "0") {
                    OU = "NULL";
                }
                if (Dept == "0") {
                    Dept = "NULL";
                }
                if (Role == "0") {
                    Role = "NULL";
                }
                if (Resource == "") {
                    Resource = "NULL";
                }
                else {
                    Resource = "'" + Resource + "'";
                }
                if (FreeByDate == "") {
                    FreeByDate = "NULL";
                }
                else {
                    FreeByDate = "'" + FreeByDate + "'";
                }

                if (ResourceName == "") {
                    ResourceName = "NULL";
                }
                else {
                    ResourceName = "'" + ResourceName + "'";
                }

                //Proficiency Fill
                var ResourceParameters =
                {
                    OU: OU,
                    Dept: Dept,
                    Role: Role,
                    FreeByDate: FreeByDate,
                    Resource: Resource,
                    Flag: "0",
                    FilterPageNo: "-1",
                    EmployeeOrToolWise: Resource,
                    ResourceName: ResourceName,
                    PageNo: intPageNo,
                    PageSize: 10
                }
                var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillFilterDataByEmployee", JSON.stringify(ResourceParameters), false);

                var ResourceParameters =
                {
                    OU: OU,
                    Dept: Dept,
                    Role: Role,
                    FreeByDate: FreeByDate,
                    Flag: "0",
                    EmployeeOrToolWise: Resource,
                    ResourceName: ResourceName,
                    PageNo: intPageNo,
                    PageSize: 10
                }
                var ResultCount = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/TotalCount", JSON.stringify(ResourceParameters), false);
            }

            var tcount = 0;
            for (var i = 0; i < Result.length; i++) {
                tcount += 1;
                if (i == 0) {
                    var gempnm = '';
                }
                if (Result[i]["YearsOfExperience"] == "0" && Result[i]["MonthsOfExperience"] == "0") {

                }
                else {
                    if (gempnm == '') {
                        strHTML += '<tr>'
                        strHTML += '<td>' + Result[i]["ResourceName"] + '</td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '</tr>'
                        gempnm = Result[i]["ResourceName"];

                        strHTML += '<tr>'
                        strHTML += '<td> </td>'
                        strHTML += '<td>' + Result[i]["Description"] + '</td>'
                        if (Result[i]["YearsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["MonthsOfExperience"] + ' Month </td>'
                        }
                        else if (Result[i]["MonthsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + ' Year </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + " Year " + Result[i]["MonthsOfExperience"] + " Months " + '</td>'
                        }

                        if (Result[i]["Proficiency"] == null) {
                            strHTML += '<td> </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["Proficiency"] + '</td>'
                        }
                        strHTML += '</tr>'
                    }

                    else if (gempnm == Result[i]["ResourceName"]) {
                        strHTML += '<tr>'
                        strHTML += '<td> </td>'
                        strHTML += '<td>' + Result[i]["Description"] + '</td>'
                        if (Result[i]["YearsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["MonthsOfExperience"] + ' Month </td>'
                        }
                        else if (Result[i]["MonthsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + ' MoYearnth </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + " Year " + Result[i]["MonthsOfExperience"] + " Months " + '</td>'
                        }

                        if (Result[i]["Proficiency"] == null) {
                            strHTML += '<td> </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["Proficiency"] + '</td>'
                        }
                        strHTML += '</tr>'
                    }

                    else if (gempnm != Result[i]["ResourceName"]) {
                        strHTML += '<tr>'
                        strHTML += '<td>' + Result[i]["ResourceName"] + '</td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '</tr>'
                        gempnm = Result[i]["ResourceName"];

                        strHTML += '<tr>'
                        strHTML += '<td> </td>'
                        strHTML += '<td>' + Result[i]["Description"] + '</td>'
                        if (Result[i]["YearsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["MonthsOfExperience"] + ' Month </td>'
                        }
                        else if (Result[i]["MonthsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + ' Year </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + " Year " + Result[i]["MonthsOfExperience"] + " Months " + '</td>'
                        }

                        if (Result[i]["Proficiency"] == null) {
                            strHTML += '<td> </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["Proficiency"] + '</td>'
                        }
                        strHTML += '</tr>'
                    }

                }
            }

            if (tcount == 0) {
                strHTML += '<tr>'
                strHTML += '<td colspan="4" width="200px"> <center>No Data available </center></td>'
                strHTML += '</tr>'
            }

            TotalRecords = ResultCount;
            Pagination();
            $("#ListByEmployee").html('');
            $("#ListByEmployee").append(strHTML);
        }
        //End by imran 15-11-2021 

        //Added by imran 15-11-2021 ListbySkill Datatable Fill
        function ListbySkill(flag, ResourceIDs) {
            //$('#srchbyskilltbl').dataTable().fnDestroy();
            $("#ListBySkill").html('');

            var strHTML = '';
            if (flag == 0) {
                var ResourceParameters =
                {
                    PageNo: intPageNo,
                    PageSize: 10
                }
                var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/GetListbyskill", JSON.stringify(ResourceParameters), false);
            }
            else {
                var OU = $("#cboOU").val();
                var Dept = $("#cboDept").val();
                var Role = $("#cboRole").val();
                var Resource = ResourceIDs;
                var FreeByDate = $("#setfltrDatefield1").val();
                var ResourceName = $("#txtResourceName").val();

                if (OU == "0") {
                    OU = "NULL";
                }
                if (Dept == "0") {
                    Dept = "NULL";
                }
                if (Role == "0") {
                    Role = "NULL";
                }
                if (Resource == "") {
                    Resource = "NULL";
                }
                else {
                    Resource = "'" + Resource + "'";
                }

                if (FreeByDate == "") {
                    FreeByDate = "NULL";
                }
                else {
                    FreeByDate = "'" + FreeByDate + "'";
                }

                if (ResourceName == "") {
                    ResourceName = "NULL";
                }
                else {
                    ResourceName = "'" + ResourceName + "'";
                }

                //Proficiency Fill
                var ResourceParameters =
                {
                    OU: OU,
                    Dept: Dept,
                    Role: Role,
                    FreeByDate: FreeByDate,
                    Resource: Resource,
                    Flag: "1",
                    FilterPageNo: "-1",
                    EmployeeOrToolWise: Resource,
                    ResourceName: ResourceName,
                    PageNo: intPageNo,
                    PageSize: 10
                }
                var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillFilterDataByEmployee", JSON.stringify(ResourceParameters), false);

                //click on skill radio button to get count according to filter
                var k = document.getElementById("Rlistbyskill").checked;
                if (k == true) {
                    var ResourceParameters =
                    {
                        OU: OU,
                        Dept: Dept,
                        Role: Role,
                        FreeByDate: FreeByDate,
                        Flag: "1",
                        EmployeeOrToolWise: Resource,
                        ResourceName: ResourceName,
                        PageNo: intPageNo,
                        PageSize: 10
                    }
                    var ResultCount = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/TotalCount", JSON.stringify(ResourceParameters), false);
                    TotalRecords = ResultCount;
                    Pagination();
                }
            }

            var tcount = 0;
            for (var i = 0; i < Result.length; i++) {
                tcount += 1;
                if (i == 0) {
                    var gempnm = '';
                }
                if (Result[i]["YearsOfExperience"] == "0" && Result[i]["MonthsOfExperience"] == "0") {

                }
                else {
                    if (gempnm == '') {
                        strHTML += '<tr>'
                        strHTML += '<td>' + Result[i]["Description"] + '</td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '</tr>'
                        gempnm = Result[i]["Description"];

                        strHTML += '<tr>'
                        strHTML += '<td> </td>'
                        //strHTML += '<td>' + Result[i]["ResourceName"] + '</td>'
                        strHTML += '<td><a href="javascript:ProjectDetails_OnClick(' + Result[i]["EmployeeID"] + ')">' + Result[i]["ResourceName"] + '</a></td>'

                        if (Result[i]["YearsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["MonthsOfExperience"] + ' Month </td>'
                        }
                        else if (Result[i]["MonthsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + ' Year </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + " Year " + Result[i]["MonthsOfExperience"] + " Months " + '</td>'
                        }

                        if (Result[i]["Proficiency"] == null) {
                            strHTML += '<td> </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["Proficiency"] + '</td>'
                        }
                        strHTML += '</tr>'
                    }

                    else if (gempnm == Result[i]["Description"]) {
                        strHTML += '<tr>'
                        strHTML += '<td> </td>'
                        //strHTML += '<td>' + Result[i]["ResourceName"] + '</td>'
                        strHTML += '<td><a href="javascript:ProjectDetails_OnClick(' + Result[i]["EmployeeID"] + ')">' + Result[i]["ResourceName"] + '</a></td>'
                        if (Result[i]["YearsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["MonthsOfExperience"] + ' Month </td>'
                        }
                        else if (Result[i]["MonthsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + ' Year </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + " Year " + Result[i]["MonthsOfExperience"] + " Months " + '</td>'
                        }

                        if (Result[i]["Proficiency"] == null) {
                            strHTML += '<td> </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["Proficiency"] + '</td>'
                        }
                        strHTML += '</tr>'
                    }

                    else if (gempnm != Result[i]["Description"]) {
                        strHTML += '<tr>'
                        strHTML += '<td>' + Result[i]["Description"] + '</td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '<td></td>'
                        strHTML += '</tr>'
                        gempnm = Result[i]["Description"];

                        strHTML += '<tr>'
                        strHTML += '<td> </td>'
                        //strHTML += '<td>' + Result[i]["ResourceName"] + '</td>'
                        strHTML += '<td><a href="javascript:ProjectDetails_OnClick(' + Result[i]["EmployeeID"] + ')">' + Result[i]["ResourceName"] + '</a></td>'
                        if (Result[i]["YearsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["MonthsOfExperience"] + ' Month </td>'
                        }
                        else if (Result[i]["MonthsOfExperience"] == 0) {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + ' Year </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["YearsOfExperience"] + " Year " + Result[i]["MonthsOfExperience"] + " Months " + '</td>'
                        }

                        if (Result[i]["Proficiency"] == null) {
                            strHTML += '<td> </td>'
                        }
                        else {
                            strHTML += '<td>' + Result[i]["Proficiency"] + '</td>'
                        }
                        strHTML += '</tr>'
                    }

                }
            }
            if (tcount == 0) {
                strHTML += '<tr>'
                strHTML += '<td colspan="4" width="200px"> <center>No Data available </center></td>'
                strHTML += '</tr>'
            }


            $("#ListBySkill").html('');
            $("#ListBySkill").append(strHTML);
        }
        //End by imran 15-11-2021

        //Added by imran 16-11-2021 filter Skill
        var YearArray = new Array();
        var MonthArray = new Array();
        var ProficiencyArray = new Array();
        function FillSkill() {
            var strHTML = '';
            var ResourceParameters =
            {
                GroupID: 7
            }

            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillSkill", JSON.stringify(ResourceParameters), false);
            for (var i = 0; i < Result.length; i++) {
                strHTML += '<tr>'

                strHTML += '<td>' + Result[i]["Description"] + '</td>'

                var tyear = "<select class='form-control' id=cboyear" + Result[i]["ToolID"] + " disabled></select>";
                strHTML += '<td>' + tyear + '</td>'
                YearArray.push("#cboyear" + Result[i]["ToolID"]);

                var tmonth = "<select class='form-control' id=cbomonth" + Result[i]["ToolID"] + " disabled></select>";
                strHTML += '<td>' + tmonth + '</td>'
                MonthArray.push("#cbomonth" + Result[i]["ToolID"]);

                var tproficiency = "<select class='form-control' id=cboproficiency" + Result[i]["ToolID"] + " disabled></select>";
                strHTML += '<td>' + tproficiency + '</td>'
                ProficiencyArray.push("#cboproficiency" + Result[i]["ToolID"]);

                var tccr = "<input id=chkcorecomptncy" + Result[i]["ToolID"] + " class='checktbl' type='checkbox' disabled>";
                strHTML += '<td>' + tccr + '</td>'

                var tselect = "<input id=chkselect" + Result[i]["ToolID"] + " class='checktbl' type='checkbox' onclick=EditCheckbox(" + Result[i]["ToolID"] + ")>";
                strHTML += '<td>' + tselect + '</td>'
                strHTML += '</tr>'
            }
            $('#FilterSkillTbl').dataTable().fnDestroy();
            $("#FilterSkill").html('');
            $("#FilterSkill").append(strHTML);

            //filling all combo value
            FillCombo();
        }
        //End by imran 16-11-2021

        //Added by imran 16-11-2021 Fill Filter Datatable skill combo value
        var datatableval = ''
        function FillCombo() {
            //Year Fill
            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillYear", "", false);
            //var s = '<option value="0">Select Year</option>';
            var s = '';
            for (var i = 0; i < Result.length; i++) {
                s += '<option value="' + Result[i].YearID + '">' + Result[i].Year + '</option>';
            }
            for (i = 0; i < YearArray.length; i++) {
                $(YearArray[i]).html(s);
            }

            //Month Fill
            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillMonth", "", false);
            //var s = '<option value="0">Select Month</option>';
            var s = '';
            for (var i = 0; i < Result.length; i++) {
                s += '<option value="' + Result[i].YearID + '">' + Result[i].Year + '</option>';
            }
            for (i = 0; i < MonthArray.length; i++) {
                $(MonthArray[i]).html(s);
            }

            //Proficiency Fill
            var ResourceParameters =
            {
                GroupID: 7
            }
            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillProficiency", JSON.stringify(ResourceParameters), false);
            //var s = '<option value="0">Select Proficiency</option>';
            var s = '<option value="0"></option>';
            for (var i = 0; i < Result.length; i++) {
                s += '<option value="' + Result[i].ParameterID + '">' + Result[i].ParameterValue + '</option>';
            }
            for (i = 0; i < ProficiencyArray.length; i++) {
                $(ProficiencyArray[i]).html(s);
            }

            if (Activated == "" | Activated == null) { }
            else {
                SkillData = SkillData.split('~~');
                //Combobox values
                k = SkillData[0].split('`');
                $("#cboOU").val(k[0]);
                $("#cboDept").val(k[1]);
                $("#cboRole").val(k[2]);
                if (k[3] == null || k[3] == "" || k[3] == "null") {
                }
                else {
                    $("#txtResourceName").val(k[3]);
                }

                if (k[4] == null || k[4] == "" || k[4] == "null") {
                }
                else {
                    $("#setfltrDatefield1").val(k[4]);
                }

                //Set datatable value
                if (SkillData[1] == null || SkillData[1] == "") { }
                else {
                    datatableval = SkillData[1].split(",");
                    DatatableSelectedID = DatatableSelectedID.split(",");

                    SkillCombocheckid = [];
                    var tcountForCombo = 0;
                    var tcountForDatatabel = 0;
                    for (i = 0; i < datatableval.length; i++) {
                        debugger;
                        n = datatableval[i].indexOf("||");

                        if (n > -1) {
                            var data = datatableval[i].split("||");
                        }
                        else {
                            var data = datatableval[i].split("|");
                        }

                        if (data == null || data == "null") {
                            tcountForCombo += 1;
                        }
                        else {
                            tcountForDatatabel += 1;
                            if (n > -1) {
                                var data = datatableval[i].split("||");
                                var datavalue = data[0].split("|");
                                var datavaluechk = data[1];

                                $("#cboyear" + DatatableSelectedID[i]).val(datavalue[1]);
                                $("#cbomonth" + DatatableSelectedID[i]).val(datavalue[2]);
                                $("#cboproficiency" + DatatableSelectedID[i]).val(datavalue[3]);
                                //if (datavaluechk[0] == "1")
                                //{
                                //    document.getElementById("chkcorecomptncy" + DatatableSelectedID[i]).checked = true;
                                //}
                                document.getElementById("cboyear" + DatatableSelectedID[i]).disabled = false;
                                document.getElementById("cbomonth" + DatatableSelectedID[i]).disabled = false;
                                document.getElementById("cboproficiency" + DatatableSelectedID[i]).disabled = false;
                                document.getElementById("chkcorecomptncy" + DatatableSelectedID[i]).disabled = false;
                                document.getElementById("chkselect" + DatatableSelectedID[i]).checked = true;
                            }
                            else {
                                datavalue = data;
                                $("#cboyear" + DatatableSelectedID[i]).val(datavalue[1]);
                                $("#cbomonth" + DatatableSelectedID[i]).val(datavalue[2]);
                                $("#cboproficiency" + DatatableSelectedID[i]).val(datavalue[3]);
                                document.getElementById("chkcorecomptncy" + DatatableSelectedID[i]).checked = true;

                                document.getElementById("cboyear" + datavalue[0]).disabled = false;
                                document.getElementById("cbomonth" + datavalue[0]).disabled = false;
                                document.getElementById("cboproficiency" + datavalue[0]).disabled = false;
                                document.getElementById("chkcorecomptncy" + datavalue[0]).disabled = false;
                                document.getElementById("chkselect" + datavalue[0]).checked = true;
                            }
                            SkillCombocheckid.push(DatatableSelectedID[i]);
                        }
                    }

                    if (tcountForCombo > 0) {
                        ListbyEmployee(1, "");
                        ListbySkill(1, "");
                    }

                    if (tcountForDatatabel > 0) {
                        ListbyEmployee(1, datatableval);
                        ListbySkill(1, datatableval);
                    }
                }
            }
        }
        //End by imran 16-11-2021

        //Added by imran 16-11-2021 to check uncheck checkbox of filter skill
        var SkillCombo = new Array();
        var SkillCombocheckid = new Array();
        function EditCheckbox(id) {
            var checkBox = document.getElementById("chkselect" + id);
            if (checkBox.checked == true) {
                SkillCombocheckid.push(id);
                document.getElementById("cboyear" + id).disabled = false;
                document.getElementById("cbomonth" + id).disabled = false;
                document.getElementById("cboproficiency" + id).disabled = false;
                document.getElementById("chkcorecomptncy" + id).disabled = false;
            }
            else {
                //SkillCombocheckid.pop(id);

                for (i = 0; i < SkillCombocheckid.length; i++) {
                    if (SkillCombocheckid[i] == id) {
                        const index = SkillCombocheckid.indexOf(id);
                        if (index > -1) {
                            SkillCombocheckid.splice(index, 1);
                        }
                    }
                }

                document.getElementById("cboyear" + id).disabled = true;
                document.getElementById("cbomonth" + id).disabled = true;
                document.getElementById("cboproficiency" + id).disabled = true;
                document.getElementById("chkcorecomptncy" + id).disabled = true;
            }
        }
        //End comment by imran 16-11-2021


        //Added by imran 16-11-2021 Filter Fill Skill Datatable Fill
        function setfilterModal() {
            SkillData = '<%= Session("SkillData") %>';
            Activated = '<%= Session("Activated") %>';
            DatatableSelectedID = '<%= Session("DatatableSelectedID") %>';
            //alert(SkillData + " --- " + DatatableSelectedID);

            //Organization Unit
            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillOU", "", false);
            var s = '<option value="0">Select Organization Unit</option>';
            for (var i = 0; i < Result.length; i++) {
                s += '<option value="' + Result[i].LocationID + '">' + Result[i].Location + '</option>';
            }
            $("#cboOU").html(s);

            //Department
            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillDept", "", false);
            var s = '<option value="0">Select Department</option>';
            for (var i = 0; i < Result.length; i++) {
                s += '<option value="' + Result[i].DepartmentID + '">' + Result[i].Department + '</option>';
            }
            $("#cboDept").html(s);

            //Role
            var Result = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/FillRole", "", false);
            var s = '<option value="0">Select Role</option>';
            for (var i = 0; i < Result.length; i++) {
                s += '<option value="' + Result[i].RoleID + '">' + Result[i].RoleDescription + '</option>';
            }
            $("#cboRole").html(s);

            //Filter Datatable Fill
            FillSkill();

        }
        //End Comment by imran 16-11-2021


        //Filter Button    
        var filterDatatableID = new Array();
        $("#btnApplyFilter").click(function () {
            SkillCombo = [];
            filterDatatableID = [];
            var ResourceIDs = '';
            for (i = 0; i < SkillCombocheckid.length; i++) {
                var id = SkillCombocheckid[i];
                var chkselect = document.getElementById("chkselect" + id);

                if (chkselect.checked == true) {
                    debugger;
                    var chkcorecomptncy = document.getElementById("chkcorecomptncy" + id);
                    var yr = $("#cboyear" + id).val();
                    var mnth = $("#cbomonth" + id).val();
                    if (chkcorecomptncy.checked == true) {
                        var prof = $("#cboproficiency" + id).val();
                        if (prof == 0 || prof == null || prof == "") {
                            //data = id + "|" + yr  + "|" + mnth  + "||"+ 0;
                            data = id + "|" + yr + "|" + mnth + "||" + 1;
                        }
                        else {
                            data = id + "|" + yr + "|" + mnth + "|" + prof + "|" + 0;
                        }
                    }
                    else {
                        // data = id + "|" + yr  + "|" + mnth  + "||"+ 0;
                        var prof = $("#cboproficiency" + id).val();
                        if (prof == 0 || prof == null || prof == "") {
                            data = id + "|" + yr + "|" + mnth + "||" + 0;
                        }
                        else {
                            data = id + "|" + yr + "|" + mnth + "||" + 1;
                        }
                    }
                    SkillCombo.push(data);
                    filterDatatableID.push(id);
                }
            }

            var DatatableSelectedID = '';
            for (i = 0; i < SkillCombo.length; i++) {
                ResourceIDs += SkillCombo[i] + ",";
                DatatableSelectedID += filterDatatableID[i] + ",";
            }

            ResourceIDs = ResourceIDs.substring(0, ResourceIDs.length - 1)
            intPageNo = 1;
            //ListbyEmployee(1,ResourceIDs);
            //ListbySkill(1, ResourceIDs);

            //Activateing Session variable
            var Res = $("#txtResourceName").val();
            if (Res == "" || Res == null) {
                Res = null;
            }
            else {
                Res = Res;
            }

            dt = $("#setfltrDatefield1").val();
            if (dt == "" || dt == null) {
                dt = null;
            }
            else {
                dt = dt;
            }

            if (ResourceIDs == "" || ResourceIDs == null) {
                ResourceIDs = 'null';
            }
            var l = $("#cboOU").val() + "`" + $("#cboDept").val() + "`" + $("#cboRole").val() + "`" + Res + "`" + dt + "`";
            var data = l + "~~" + ResourceIDs;
            var ActivateSession = ajaxCall("PM_EmployeeSkillsSearch.aspx/ActivateSession", "POST", "application/json;charset=utf-8", "json", JSON.stringify({ data: data, DatatableSelectedID: DatatableSelectedID }));

            if (ActivateSession.d == "OK") {
                $("#btnclear").show();
                $('#setfilterModal').modal('hide');
                window.location.reload(true);
            }
        });


        function ClearFilter() {
            $("#btnclear").hide();
            var ClearSession = ajaxCall("PM_EmployeeSkillsSearch.aspx/ClearSession", "POST", "application/json;charset=utf-8", "json", "");

            if (ClearSession.d == "OK") {
                ListbyEmployee(0, '');
                ListbySkill(0, '');
                window.location.reload(true);
            }
        }


        function AJAXCallWithResult(url, param, async) {
            $.ajax({
                url: encodeURI(strUrl) + url,
                type: "POST",
                data: param,
                async: async,
                dataType: "json",
                contentType: "application/json;charset-utf=8",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('Authorization', 'bearer ' + localStorage.getItem("access_token-I"));
                },
                success: function (data) {
                    ajaxResult = data;
                },
                error: function (err) {
                    console.log(err);
                    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + ""
                }
            });
            return ajaxResult;
        }

        function ProjectDetails_OnClick(EmployeeID) {
            GeneratePK_TokenResumePage(EmployeeID);
             window.open("../Resources/RM_Resume.aspx?PKToken=" + R_CurrentToken + " &EmployeeID=" + EmployeeID + "&TagId=426&MasterTagId=3861", "", "resizable=yes,scrollbars=yes,left=" + (window.screen.width - 920) / 2 + ",top=" + (window.screen.height - 900) / 2 + ",width=900,height=600");
        }

        /////////////////////  Resume Token Generation Code //////////////////////////////////
        var R_CurrentToken = '';
        function GeneratePK_TokenResumePage(EmployeeID) {
            try {

                var EmployeeID = EmployeeID;
                var generatedtoken = ajaxCall("PM_EmployeeSkillsSearch.aspx/GeneratePK_TokenResumePage", "POST", "application/json;charset=utf-8", "json", JSON.stringify({ EmployeeID: EmployeeID }));
                if (generatedtoken != undefined) {
                    R_CurrentToken = generatedtoken.d;
                    ValidatePK_TokenResumePage(EmployeeID);
                }
            }
            catch (ex) {
                //alert(ex.message());
            }
        }

        var R_PKToken;
        function ValidatePK_TokenResumePage(EmployeeID) {

            try {

                var EmployeeID = EmployeeID;
                R_PKToken = R_CurrentToken;
                var validatetoken = ajaxCall("PM_EmployeeSkillsSearch.aspx/ValidatePK_TokenResumePage", "POST", "application/json;charset=utf-8", "json", JSON.stringify({ PKToken: m_PKToken }));
                if (validatetoken != undefined) {
                    if (validatetoken.d == false) {
                        window.location.href = "../../General/CommonPage.aspx?MasterTagID=1836";
                    }
                }
            }
            catch (ex) {
                //alert(ex.message());
            }
        }

        var ajaxResult;
        function ajaxCall(url, type, contentType, dataType, data) {
            $.ajax({
                url: url,
                type: "POST",
                data: data,
                async: false,
                dataType: "json",
                contentType: "application/json;charset-utf=8",

                success: function (data) {

                    ajaxResult = data;
                },
                error: function (err) {
                    console.log(err);
                    window.location.href = "../../General/ErrorPage.aspx?Mode=AJAXError&Error=" + err + "";
                }
            });
            return ajaxResult;
        }

        /////////////////////  End Resume Token Generation Code //////////////////////////////////


        /////////////////////  Pagination Code //////////////////////////////////

        function Pagination() {
            var ProjectID = ProjectId;
            //if (ProjectID != 0)
            //{
            var currentRecord = (intPageNo * 10);
            //var currentRecord = (intPageNo * 5);
            if (parseInt(intPageNo) == 1) {
                $("#btnprevious").addClass("fa-disabled");
                $("#btnnext").removeClass("fa-disabled");
                $("#LinkPrevious").removeAttr("Onclick");
                $("#LinkNext").attr("Onclick", "NextList()");
            }
            if (parseInt(currentRecord) > parseInt(TotalRecords) && intPageNo == 1) {
                $("#btnprevious").addClass("fa-disabled");
                $("#btnnext").addClass("fa-disabled");
                $("#LinkPrevious").removeAttr("Onclick");
                $("#LinkNext").removeAttr("Onclick");
            }
            else if (parseInt(currentRecord) >= parseInt(TotalRecords)) {
                $("#btnprevious").removeClass("fa-disabled");
                $("#btnnext").addClass("fa-disabled");
                $("#LinkPrevious").attr("Onclick", "PrevList()");
                $("#LinkNext").removeAttr("Onclick");
            }

            else if (parseInt(intPageNo) > 1 && parseInt(currentRecord) < parseInt(TotalRecords)) {
                $("#btnprevious").removeClass("fa-disabled");
                $("#btnnext").removeClass("fa-disabled");
                $("#LinkPrevious").attr("Onclick", "PrevList()");
                $("#LinkNext").attr("Onclick", "NextList()");

            }
            if (parseInt(SearchRecords) == "1" && parseInt(currentRecord) >= parseInt(TotalRecords)) {
                $("#btnprevious").addClass("fa-disabled");
                $("#btnnext").addClass("fa-disabled");
                $("#LinkPrevious").removeAttr("Onclick");
                $("#LinkNext").removeAttr("Onclick");
            }
            //} else {
            //    TotalRecords = 0;
            //    $("#btnprevious").addClass("fa-disabled");
            //    $("#btnnext").addClass("fa-disabled");
            //    $("#LinkPrevious").removeAttr("Onclick");
            //    $("#LinkNext").removeAttr("Onclick");
            //}

            if (isIE() == "IE") {
                if ($("#btnprevious").hasClass("fa-disabled")) {
                    $("#btnprevious").addClass("clsPaginationEnableDisable");
                }
                else {
                    $("#btnprevious").removeClass("clsPaginationEnableDisable");
                }
                if ($("#btnnext").hasClass("fa-disabled")) {
                    $("#btnnext").addClass("clsPaginationEnableDisable");
                }
                else {
                    $("#btnnext").removeClass("clsPaginationEnableDisable");
                }
            }

            $("#TotalRecords").html("");
            $("#TotalRecords").html(TotalRecords);
        }

        function isIE() {
            var brwser = '';
            var ua = navigator.userAgent, tem,
                M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
            if (/trident/i.test(M[1])) {
                tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                return 'IE';
            }
            if (M[1] === 'Chrome') {
                tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
                if (tem != null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
                brwser = 'CR';
            }
            else if (M[1] === 'Firefox') {
                tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
                if (tem != null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
                brwser = 'FF';
            }
            M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
            if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
            return brwser;
        }

        function PrevList() {
            intPageNo--;
            if (Activated == "" | Activated == null) {
                var k = document.getElementById("Rlistbyrsrs").checked;

                if (k == true) {
                    ListbyEmployee(0, '');
                    ListbySkill(0, '');
                }
                else {
                    ListbyEmployee(0, '');
                    ListbySkill(0, '');
                    var ResultCount = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/TotalCountWithoutForSkill", "", false);
                    TotalRecords = ResultCount;
                    $("#TotalRecords").html("");
                    $("#TotalRecords").html(TotalRecords);
                    Pagination();
                }
            }
            else {
                ListbyEmployee(0, '');
                ListbySkill(0, '');
            }
        }

        function NextList() {
            intPageNo++;
            if (Activated == "" | Activated == null) {
                var k = document.getElementById("Rlistbyrsrs").checked;

                if (k == true) {
                    ListbyEmployee(0, '');
                    ListbySkill(0, '');
                }
                else {
                    ListbyEmployee(0, '');
                    ListbySkill(0, '');

                    var ResultCount = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/TotalCountWithoutForSkill", "", false);
                    TotalRecords = ResultCount;
                    $("#TotalRecords").html("");
                    $("#TotalRecords").html(TotalRecords);
                    Pagination();
                }
            }
            else {
                ListbyEmployee(1, '');
                ListbySkill(1, '');
            }
        }
        /////////////////////  End Pagination Code //////////////////////////////////


        function ListBySkillCount()
        {
            if (Activated == "" | Activated == null)
            {
                $("#btnclear").hide();
                var k = document.getElementById("Rlistbyrsrs").checked;

                if (k == true) {
                    ListbyEmployee(0, '');
                    ListbySkill(0, '');
                }
                else
                {
                    intPageNo = 1;
                    ListbyEmployee(0, '');
                    ListbySkill(0, '');

                    //To get Skill Count
                    var ResultCount = AJAXCallWithResult("/api/RM_EmployeeSkillSearch/TotalCountWithoutForSkill", "", false);
                    TotalRecords = ResultCount;
                    $("#TotalRecords").html("");
                    $("#TotalRecords").html(TotalRecords);
                    Pagination();
                }
            }
            else {
                intPageNo = 1;
                setfilterModal();
            }
        }

        function ListByEmployeeCount() {
            if (Activated == "" | Activated == null) {
                $("#btnclear").hide();
                intPageNo = 1;
                ListbyEmployee(0, '');
                ListbySkill(0, '');
            }
            else {
                intPageNo = 1;
                setfilterModal();
            }
        }

    </script>
</body>
</html>