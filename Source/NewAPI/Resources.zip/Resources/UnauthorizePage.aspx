﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="UnauthorizePage.aspx.vb" Inherits="Whizible.UnauthorizePage" %>

<!DOCTYPE html>

<html>
<head runat="server">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Resource</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">    
    <link rel="stylesheet" href="../../../Whizible2.0/bootstrap/css/bootstrap.min.css?v=1">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="../../../Whizible2.0/fontawesome/css/all.css?v=2">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom.css?v=3">
    <link rel="stylesheet" href="../../../Whizible2.0/dist/css/style_custom_project.css?v=3.1">

</head>
<body class="clsBody" MS_POSITIONING="GridLayout">
    <form id="form1" method="post" runat="server">
        <div class="container-fluid pt-1 pb-1 mb-1 text-right">
           <div style="text-align:center;font-size:15px;">
               You are not authorized to view this record.
           </div>             
           <%-- <a href="../NewAPI/Resources/RM_ResourcePlanIndex.aspx" class="btn borderbtn backbtn" id="" data-toggle="tooltip" data-placement="bottom" title="Back to Resource Configuration">Back</a>--%>
        </div>
    </form>
</body>
</html>
